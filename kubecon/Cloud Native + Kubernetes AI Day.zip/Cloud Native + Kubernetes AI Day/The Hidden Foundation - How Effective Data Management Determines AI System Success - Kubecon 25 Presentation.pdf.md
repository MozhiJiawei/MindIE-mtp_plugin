# 《The Hidden Foundation - How Effective Data Management Determines AI System Success》PDF总结
## 一、演讲者信息
- **姓名**：Keith McClellan  
- **职位**：Splunk美洲区Field CTO（Splunk为Cisco旗下公司）  
- **背景**：20余年数据 analytics 与企业基础设施领域经验，擅长将复杂技术概念转化为业务成果，深耕数据平台、云原生架构及受监管行业，在解决方案工程、客户体验与战略规划领域具备领导力。


## 二、当前AI项目的严峻现状与数据价值
### 1. AI项目失败率高
- 70%-85%的AI项目未能达到预期目标；  
- MIT研究显示，超95%的AI项目无法产生投资回报率（ROI）。

### 2. 数据驱动组织的优势
- 数据驱动型企业达成营收目标的概率高出58%；  
- 从AI项目中获得积极结果的概率高出150%。

### 3. 核心挑战
若数据未具备“AI就绪”能力，不仅无法支撑当前AI需求，更无法适配未来场景。


## 三、“基础”AI实施的复杂性
- **架构组成**：3个智能体平台（Agentic Platform）、5个数据源；  
- **风险点**：存在18个独立故障点（即使采用“最少工具”策略）；  
- **潜在问题**：任一集成点故障、新增数据源/智能体均可能导致系统问题。


## 四、数据管理的五大支柱（成功基础）
### 1. 战略与治理（Strategy & Governance）
- 核心问题：需哪些人员参与？短期/长期目标是什么？需哪些数据及数据位置？流程自动化程度？如何实时适配？如何融入现有流程与文化？  
- 关键动作：管理层对齐、领域导向的数据治理、联邦化管理。

### 2. 数据质量与准备（Data Quality and Preparation）
- 核心原则：“质量胜于数量”（Quality eats quantity for breakfast）；  
- 关键动作：  
  - 自动化为核心（可借助AI监控数据质量）；  
  - 实时异常检测（提前识别数据漂移、缺失等问题，避免影响下游）；  
  - 明确数据血缘（追溯数据来源，确保可信度）；  
  - 保障数据清洁度、偏差检测、验证与告警、相关性。

### 3. 基础设施与平台（Infrastructure and Platform）
- 核心原则：优先选择**开放标准**（非特定技术），兼容性为王，精简技术栈；  
- 关键技术/动作：  
  - 采用Apache Iceberg、OpenTelemetry、eBPF等开放标准；  
  - 规划灾备（DR）向高可用（HA）转型；  
  - 集中化元数据管理（支持目录、血缘、版本历史）；  
  - 实现联邦数据架构（Data Fabric）与实时同步；  
  - 支持容器化/云原生部署、混合/多云架构；  
  - 让DataOps支撑MLOps，将CI/CD融入数据与AI工作流。

### 4. 安全与合规（Security and Compliance）
- 核心认知：AI放大数据价值的同时，也会放大风险；  
- 关键动作：  
  - 数据加密（传输中+静态存储）；  
  - 平衡安全与访问（建立RBAC/ABAC权限控制）；  
  - 采用隐私保护技术（处理含PII的数据集，保障广泛访问）；  
  - 合规自动化（含补救措施）；  
  - 单独保障AI模型安全。

### 5. 运营卓越（Operational Excellence）
- 核心目标：驱动业务价值；  
- 关键动作：  
  - 持续改进（非一次性实施）；  
  - 统一可观测性（将数据/AI可观测性与应用/IT可观测性整合）；  
  - 用AI管理AI与数据管道；  
  - 追踪成本与性能（关联业务成果，监控ROI）；  
  - 提供告警、指标支持。


## 五、分阶段实施周期（Phased Implementation Cycle）
### 1. 第一阶段（1-3个月）：基础与评估（Foundation and Assessment）
| 步骤 | 核心任务 |
|------|----------|
| 步骤0：评估 | 梳理现有数据（类型、来源、当前管理/治理方式）、识别差距与数据囤积问题 |
| 步骤1：愿景与对齐 | 明确目标、确定相关利益方、分配责任/问责人、分析当前问题解决方案 |
| 步骤2：治理 | 确定数据治理框架（AI场景是否需调整）、制定政策、判断是否复用现有流程 |

### 2. 第二阶段（4-9个月）：平台与试点（Platform and Pilot）
| 步骤 | 核心任务 |
|------|----------|
| 步骤3：基础设施转型 | 部署云原生数据平台（含统一数据架构与联邦能力）、按“最少工具”策略选择存储（热数据+长期留存数据）、判断数据集中化的成本合理性（否则默认联邦化） |
| 步骤4：管道开发 | 构建自动化智能数据管道（内置质量控制）、部署持续交付工作流、实施数据目录与元数据管理 |

### 3. 第三阶段（10-12个月）：运营与评估（Operate and Evaluate）
| 步骤 | 核心任务 |
|------|----------|
| 步骤5：部署AI用于数据 | 用AI提升数据质量与异常检测、监控数据偏差与公平性、建立性能追踪机制 |
| 步骤6：实施、优化与扩展 | 向试点用户推广、追踪系统成本与性能、优化并新增自助服务能力、部署“人机协同”智能体工作流 |
| 步骤7：评估结果与规划下一步 | 复盘成功指标（确保正ROI）、平衡业务影响与技术影响、识别差距与下一个高价值用例 |


## 六、成功衡量标准（Measuring Success）
| 维度 | 核心指标 |
|------|----------|
| 数据质量 | 数据的“五V”（Volume、Velocity、Variety、Veracity、Value）均>90%；治理、血缘、访问控制覆盖>90%的数据源 |
| AI就绪度 | 文化接受度（Cultural Acceptance）、AI工具采用评分卡（AI Tool Adoption Rubric） |
| 业务影响 | 洞察获取时间加快60%、人力工作减少30%、实现成本降低型正ROI |


## 七、关键收获（Key Takeaways）
1. **从价值出发**：成功具有传染性，启动阶段需平衡ROI与成功概率；  
2. **投资人与文化**：全员对齐目标，核心是减少人力重复工作（human toil）；  
3. **自动化一切**：现代数据管理复杂度高，需借助AI实现自动化；  
4. **规划平台，实施项目**：构建可扩展、可复用的基础设施（支撑多项目），避免“贪大求全”（don’t boil the ocean）；  
5. **衡量与迭代**：数据管理是长期旅程，需建立反馈与监控循环，推动成熟度提升。


## 八、更多信息来源
### 1. 演讲者联系方式
- LinkedIn：https://www.linkedin.com/in/keithmcclellan/  
- 个人博客：https://www.fieldcto.ai  

### 2. 参考资料
- Forbes：https://www.forbes.com/councils/forbestechcouncil/2024/11/15/why-85-of-your-ai-models-may-fail/  
- Fortune：https://fortune.com/2025/08/18/mit-report-95-percent-generative-ai-pilots-at-companies-failing-cfo/  
- AvePoint白皮书：https://cdn.avepoint.com/pdfs/en/shifthappens/AI-IM-Whitepaper-v4.pdf  
- MIT Technology Review：https://www.technologyreview.com/2021/10/14/1037054/getting-the-most-from-your-data-driven-transformation-10-key-principles/#:~:text=The%20importance%20of%20data%20to,changing%20the%20game%20of%20basketball  

### 3. Splunk资源
- Splunk Perspectives Blog：https://www.splunk.com/en_us/blog/perspectives.html