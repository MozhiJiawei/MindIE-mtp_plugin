# AI Day 2025 分享总结：Kubernetes“运行中”状态的现实核查
## 一、分享背景
- **演讲者**：Ron Kahn（Nvidia 高级软件工程师）
- **场合**：CLOUD NATIVE+ KUBERNETES AI DAY NORTH AMERICA（2025年北美云原生+Kubernetes AI日）
- **核心主题**：解决Kubernetes中“Job显示‘运行中’（Running），但实际无业务进展”的状态不符问题，聚焦AI训练场景（如LLM、PyTorch训练）的K8s状态核查。


## 二、数据科学家的典型工作场景（问题呈现）
以“LLM训练作业”为例，还原问题发生的完整时间线：
1. **9:00 AM：提交训练作业**  
   执行命令 `kubectl apply -f llm-training.yaml`，K8s返回 `trainjob.trainer.kubeflow.org/llm created`，作业提交成功。
2. **9:01 AM：K8s显示作业“就绪”**  
   执行命令 `kubectl get trainjobs.trainer.kubeflow.org llm -oyaml | yq ".status.jobsstatus"`，返回状态为 `active:1, failed:0, ready:1, succeeded:0, suspended:0`，作业被标记为“就绪”，开发者误判进展正常。
3. **11:00 AM：日志暴露核心问题**  
   查看Pod日志 `kubectl logs llm-node-0-0-rj4sf`，反复出现 **IPv6地址解析失败错误**：  
   `[c10d] The IPv6 network addresses of(llm-node-0-0.llm,29500)cannot be retrieved (gai error:-3-Temporary failure in name resolution)`，训练无任何进展，但GPU仍在消耗（成本约1000美元）。
4. **关键矛盾**：K8s始终显示Job“运行中”，但实际训练因网络问题完全停滞。


## 三、Pod从创建到就绪的完整里程碑
K8s中Pod的生命周期分为**Pending阶段**和**Running阶段**，各阶段的核心动作决定了“运行中”状态的判定逻辑：

| 阶段          | 核心步骤（按顺序）                                                                 |
|---------------|-----------------------------------------------------------------------------------|
| Pending阶段   | 1. 用户向API服务器发送Pod请求，Pod创建；<br>2. 调度器（scheduler）将Pod分配到具体Node；<br>3. Kubelet拉取Init容器镜像 |
| Running阶段   | 1. Init容器运行并完成初始化；<br>2. Kubelet拉取应用（App）容器镜像；<br>3. 启动应用容器；<br>4. Pod就绪探针（Readiness Probe）通过，Pod标记为“Ready” |


## 四、PyTorch训练作业的Kubernetes实体与通信逻辑
### 1. 核心K8s实体
- **Headless Service**：服务名 `pytorch-training-svc`，用于Pod间通信的服务发现。
- **Worker Pods**：按“Rank”划分角色，共3个Pod：
  - Rank 0（Worker/Leader Pod）：`pytorchtraining-0`（主节点，协调训练）；
  - Rank 1（Worker Pod）：`pytorchtraining-1`；
  - Rank 2（Worker Pod）：`pytorchtraining-2`。

### 2. 通信机制
- **服务发现（DNS解析）**：通过Headless Service实现Pod IP映射，例：  
  `pytorch-training-0.svc → 10.0.1.10`、`pytorch-training-1.svc → 10.0.1.11`、`pytorch-training-2.svc → 10.0.1.12`。
- **训练通信模式**：3种核心模式支撑分布式训练：
  - All-Reduce（环形通信）：Pod 0 ↔ Pod 1 ↔ Pod 2 环形数据同步；
  - Broadcast（广播）：Pod 0（Leader）向Pod 1、Pod 2同步数据；
  - Point-to-Point（点对点）：Pod间直接通信（如Pod 0↔Pod 2）。


## 五、核心矛盾：“运行中（Running）”≠“训练中（Training）”
### 1. 研究者的预期（业务视角）
- GPU利用率＞0%（资源实际消耗）；
- 数据正在被处理（业务逻辑推进）；
- 研究任务按计划进展（最终目标达成）。

### 2. Kubernetes的现实（基础设施视角）
- 仅判定“局部健康”：所有Pod通过**个体就绪探针**、网络服务创建完成、存储挂载成功；
- 忽略“关键环节”：未检查Pod间网络连通性（如DNS解析、IPv6通信）、未验证应用层健康状态；
- 结论：K8s确认“组件正常”，但未保障“整体业务正常”。


## 六、解决方案：“运行中”状态异常的行动 plan
### 1. 训练前：执行“预检（Pre-flight Check）”
在**Init容器**中嵌入验证逻辑，提前排除基础问题：
- 验证DNS解析（避免案例中的IPv6解析失败）；
- 验证Pod间网络连通性（如端口通断、跨Node通信）；
- 验证存储可访问性（如数据集挂载、 checkpoint目录权限）。

### 2. 训练中：主动监控（Monitor Actively）
- **实时错误监控**：持续采集Pod日志，识别高频错误（如网络、存储、GPU驱动错误）；
- **业务进展追踪**：验证checkpoint文件写入（确认数据处理正常）；
- **资源利用率监控**：实时查看GPU利用率（若长期为0%，立即告警）；
- **应用健康保障**：配置**容器存活探针（Liveness Probe）**，当应用卡死时自动重启Pod。


## 七、总结
本次分享聚焦AI训练场景下K8s状态的“表象与现实”差距，核心结论为：Kubernetes的“Running”状态仅代表基础设施组件正常，需通过“训练前预检+训练中全维度监控”，补充业务层、网络层的健康验证，才能避免“资源空耗却无业务进展”的问题，保障AI训练效率与成本可控。