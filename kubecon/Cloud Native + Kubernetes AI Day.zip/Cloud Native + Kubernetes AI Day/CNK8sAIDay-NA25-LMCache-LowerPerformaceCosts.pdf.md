# LMCache：降低企业LLM推理性能成本（PDF总结）
## 一、演讲者信息
| 姓名 | 身份与核心背景 |
|------|----------------|
| Junchen Jiang | - LMCache联合创始人<br>- Tensormesh公司CEO、芝加哥大学计算机科学副教授<br>- 15+年系统研究经验，获NSF CAREER、CMU SCS最佳论文等荣誉<br>- 开创KV缓存技术（含KV缓存编码、混合、共享、转换） |
| Martin Hickey | - IBM开源开发者，LMCache核心维护者<br>- Helm emeritus核心维护者、TOC成员<br>- 贡献至LMCache、Helm、Kubernetes、Open Telemetry、OpenStack等项目<br>- 29年企业与开源软件从业经验 |


## 二、LLM推理的趋势与挑战
### 1. 核心趋势：LLM推理规模将爆发
- **供需差异**：仅约10家公司专注于训练新LLM，但数百万应用和组织需运行LLM推理（Sam Altman：“所有产品与服务集成智能将成为标配”）。
- **硬件倾斜**：据Gartner预测，到2028年，超过80%的AI硬件将专门用于推理（Armand Ruiz，IBM）。

### 2. 长上下文推理：机遇与核心挑战
#### （1）重大机遇
- 应用场景：支持聊天记录、代码仓库、书籍、业务文档、新闻、视频、音频、会议纪要等长文本输入（Eric Schmidt：“大规模长上下文窗口将带来远超预期的全球影响”）。

#### （2）关键挑战
- **延迟升高**：响应时间随上下文长度增长而显著增加（以Llama-3 8B@A40 GPU为例，上下文从5K tokens增至120K tokens时，延迟从约5s升至40s）。
- **成本上升**：GPU成本随使用量和上下文长度线性增长（同上模型，上下文120K tokens时，GPU成本较5K tokens时提升近20倍）。
- **现有方案局限**：传统推理方式未解决“上下文共享”问题，单独处理查询效率低，规模化时性能与成本矛盾突出。


## 三、KV Cache基础与下一代需求
### 1. 什么是KV Cache？
- **定义**：LLM推理中存储“键（Key）-值（Value）对”的缓存机制，用于避免重复计算，加速token生成。
- **核心流程**：  
  输入序列→Tokenization→检查缓存是否存在对应KV对→①存在：从缓存读取；②不存在：计算KV对→存储至缓存→生成输出token。

### 2. 传统KV Cache的问题
- 局限于“单查询-单引擎”，无法跨查询、跨引擎共享上下文（如多用户查询同一本书/文档时，需重复计算KV对）。

### 3. 优化方向：将KV Cache移出GPU
- **CPU卸载**：将GPU中的KV缓存持久化到CPU，缓解GPU内存压力。
- **前缀缓存**：跨查询、跨引擎共享KV缓存（“一次预填充，多引擎复用”）。
- **PD解耦**：在单个查询中跨引擎传输KV缓存，提升资源利用率。

### 4. 下一代KV Cache的核心需求
需支持多场景缓存语义，包括：GPU-GPU传输、GPU-CPU卸载、CPU-CPU传输、存储卸载（适配vLLM、SGLang等推理引擎，及S3、Mooncake、InfiniStore、Redis等存储后端）。


## 四、LMCache：开源高效KV缓存层
### 1. 定位：首个开源且最高效的KV缓存层
- 核心目标：解决LLM推理中“高延迟、高成本”问题，尤其优化长上下文场景的TTFT（首次token生成时间）和吞吐量。

### 2. 核心挑战与解决方案
| 面临挑战 | LMCache解决方案 |
|----------|----------------|
| 1. KV缓存语义效率低（分页内存拖累L2/L3存储I/O，进而放缓推理引擎） | 集成批处理、流水线等I/O优化技术，提升缓存读写效率 |
| 2. 无法与分页内存推理引擎（vLLM、SGLang）协同（新模型每5天发布一个，需频繁调整内存分配） | 适配性强：vLLM等引擎调整调度器/内存分配器时，LMCache仅需极少更新 |
| 3. 缺乏KV缓存管理交互API（运维人员无法直接控制缓存） | 提供实时API：支持管理员/路由器查看、移动、清理KV缓存 |

### 3. 关键特性
- **本地优先**：兼容无高端硬件的推理引擎，无需依赖大模型专用设备。
- **健壮可组合**：可配置多推理引擎，部署于各类云生态。
- **可扩展**：支持多推理引擎与分布式服务框架。
- **开源宽松**：开源缓存层，无严苛许可限制，降低企业使用门槛。


## 五、LMCache的部署、架构与流程
### 1. 云原生部署架构
- **核心组件**：用户请求→路由器→vLLM引擎（模型A/B/C）→可共享KV缓存存储（LMCache）→监控网关（Prometheus）→监控UI（Grafana）+ 水平自动扩缩模块。
- **适配环境**：支持K8s、KServe、Ray等云生产环境。

### 2. 生产级应用与生态
- **生态地位**：vLLM推理栈的“默认KV缓存标准”，兼容NVIDIA Dynamo、llm-d等框架。
- **数据规模**：每周处理300TB+ KV缓存数据，12.8亿命中token。
- **企业采用**：早期用户/设计伙伴包括NVIDIA、Google、Microsoft、腾讯、字节跳动、Red Hat、Bloomberg、Salesforce、Palo Alto Networks等。
- **标准化路径**：2025年计划通过PyTorch基金会项目完成标准化。

### 3. vLLM推理引擎与LMCache协同流程
1. 用户应用发送Prompt请求（LLM查询）；
2. vLLM引擎（含LMCache连接器）查询KV缓存：
   - **缓存命中**：返回缓存KV块，注入模型缓存（跳过重复计算）；
   - **缓存未命中**：正常计算新KV对；
3. 生成剩余token，向用户返回输出（无需等待缓存存储）；
4. 异步后台存储新KV块至LMCache（CPU/磁盘）。

### 4. 高层架构与关键组件
#### （1）高层架构
- 路由器→推理引擎→LMCache实例→存储后端（内存/GPU内存/CPU SSD/远程存储）；
- 传输通道：支持NVLink（GPU间）、RDMA（高性能网络）、TCP（通用网络）。

#### （2）KV缓存卸载策略
| 存储层级 | 策略 |
|----------|------|
| GPU内存 | 卸载溢出KV缓存，按需复用 |
| CPU DRAM | 异步写入，LRU淘汰策略，预取热KV缓存，复用时分批上传 |
| 磁盘/远程存储 | 长期存储冷KV缓存，复用时分批拉取 |

#### （3）核心组件
- **连接器**：集成vLLM、SGLang等推理引擎，处理缓存命中/未命中逻辑。
- **缓存索引**：映射token序列到KV缓存条目及位置，支持跨请求、跨实例查询，含分块策略与哈希方案。
- **内存对象与分配器**：本地CPU后端自定义分配器，支持GPU-CPU传输、NUMA亲和性、驱逐策略。
- **异步卸载**：非阻塞式KV缓存块卸载/加载，不占用GPU计算周期。
- **远程连接器**：插件化支持S3、Redis、Mooncake、NIXL等远程存储后端。

### 5. KV缓存传输与管理API
#### （1）传输流程（GPU模型运行器）
start_load_kv() → wait_for_layer_load() → Attention 1 → save_kv_layer() → ... → Attention N → save_kv_layer() → wait_for_save()

#### （2）管理API（LMCache Controller）
- Lookup：查询指定token列表的KV缓存；
- Clear：清理KV缓存；
- Pin：持久化KV缓存或设置TTL（过期时间）；
- Move：将KV缓存迁移至不同存储位置；
- Compress：压缩KV缓存；
- CheckFinish：检查非阻塞控制事件是否完成。


## 六、资源与核心要点
### 1. 关键资源
- 官网：https://lmcache.ai  
- 代码仓库：https://github.com/LMCache/LMCache  
- 文档：https://docs.lmcache.ai  
- 快速开始示例：https://docs.lmcache.ai/getting_started/quickstart/index.html  
- 技术报告：https://lmcache.ai/tech_report.pdf  

### 2. 核心要点
- LLM推理需求爆发，但高延迟、高成本是企业落地关键障碍；
- KV缓存是解决上述问题的核心技术，而LMCache是当前开源领域的“标准方案”；
- LMCache通过I/O优化、引擎适配、管理API三大能力，实现“降本、提速、规模化”，已被头部企业验证。