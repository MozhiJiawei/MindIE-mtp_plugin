# 资源公平性与利用率：基于Kueue的异构批处理/ML平台方案总结
## 一、文档基本信息
- **主题**：异构批处理/ML（机器学习）平台的资源公平性与利用率优化（基于Kueue工具）
- **主讲人**：Gabe Saba（Google，联系方式：邮箱gabesaba@google.com、GitHub@gabesaba、Kubernetes Slack@gabesaba）；Yuki Iwai（CyberAgent, Inc.，联系方式：邮箱yuki.iwai.tz@gmail.com、GitHub@tenzen-y、Kubernetes Slack@tenzen-y）
- **场景**：Cloud Native+Kubernetes AI Day North America（北美云原生+Kubernetes AI日）


## 二、Kueue核心定位与功能
Kueue是面向异构批处理/ML平台的资源调度与配额管理工具，核心分为两大模块：

### 1. AI工作负载级调度器（AI Workload-level Scheduler）
- **调度策略**：采用“全有或全无”（all-or-nothing）调度，确保工作负载要么获得全部所需资源，要么不占用资源，避免资源碎片化。
- **控制面优化**：支持延迟Pod创建（delayed Pod creation），减轻控制面组件（如Kubernetes API Server）的负载。
- **跨集群能力**：实现多集群工作负载调度（multi-cluster workloads dispatching），灵活分配跨集群资源。

### 2. 资源配额管理器（Resource Quota Manager）
- **多租户支持**：实现多租户配额管理（multi-tenant quota management），隔离不同租户的资源使用。
- **资源偏好控制**：允许用户配置资源偏好（control over resource preferences），优先分配符合需求的资源（如特定类型GPU）。
- **公平共享基础**：提供公平资源共享（fair resource sharing）能力，为后续公平性方案奠定基础。


## 三、AI工作负载的资源公平性目标与Kueue解决方案
### 1. 核心目标
- **最大化利用率**：AI工作负载依赖GPU等昂贵加速器，需避免资源闲置；
- **公平分配**：有限的加速器资源需在组织内（多团队、多层级）公平共享。

### 2. 三大核心解决方案
#### （1）带抢占的公平共享（Fair Sharing with Preemption）
- **核心算法**：基于**Dominant Resource Share（DRS，主导资源份额）**，DRS值反映资源使用与配额的比例，是公平共享算法的核心指标。
- **调度逻辑**：DRS值越高，说明该队列资源使用越超预期，调度时优先抢占其资源，分配给DRS值更低、更需要资源的队列。
- **示例场景**（48个GPU，RootCohort下含3个队列）：
  - CQ1权重1.5（应占18个GPU）、CQ2/CQ3权重1.0（各应占15个GPU）；
  - 若CQ2 DRS值升至167（超配额），则抢占CQ2部分GPU，分配给CQ1/CQ3，最终使三者DRS值回归均衡（均接近0）。

#### （2）层级公平共享（Hierarchical Fair Sharing）
- **核心逻辑**：支持多层级资源分配（如“RootCohort→Cohort（部门）→子队列（团队）”），每个层级均配置权重，通过DRS算法实现层级间、层级内的双重公平。
- **调度逻辑**：同“带抢占的公平共享”，DRS值越高的队列（无论层级）优先被抢占，确保资源在组织架构各层级中按权重分配。
- **示例场景**（96个GPU，RootCohort下含3个Cohort）：
  - CohortA权重1.5（应占36个GPU）、CohortB/C权重1.0（各占30个GPU）；
  - CohortA下的LeftA（权重1.0）、RightA（权重1.5）再按权重分配36个GPU，若LeftA DRS值过高，则抢占其资源给RightA，维持层级内公平。

#### （3）准入公平共享（Admission Fair Sharing, AFS）
- **核心差异**：区别于前两种“基于当前资源”的调度，AFS结合**历史资源消耗数据**，避免某团队长期独占资源或突发请求抢占资源。
- **工作流程**：
  1. **定期快照**：周期性获取各LocalQueue（本地队列）的计算资源使用快照；
  2. **惩罚值计算**：基于快照用“指数移动平均”计算惩罚值，每“半衰期”对历史快照值衰减50%（避免旧数据影响）；
  3. **入口惩罚补充**：针对突发请求，新增“入口惩罚”（基于实时请求量），防止某团队通过突发请求绕过历史惩罚；
  4. **调度优先级**：优先准入惩罚值更低的LocalQueue的工作负载，确保历史消耗少、当前需求合理的团队获得资源。
- **示例场景**：
  - Team A历史惩罚值100（长期高消耗）、Team B惩罚值10（低消耗），则优先调度Team B的工作负载；
  - 若Team B突发大量请求，入口惩罚值升至1000，则暂时降低其优先级，避免独占资源。


## 四、实践与后续参考
### 1. 尝试Kueue
- 官方文档与实践入口：https://kueue.sigs.k8s.io/

### 2. Kueue项目展厅
- **位置**：19B（B楼1层，B3-B5展厅，解决方案展示区）；
- **时间**：周二至周四（全天开放）。