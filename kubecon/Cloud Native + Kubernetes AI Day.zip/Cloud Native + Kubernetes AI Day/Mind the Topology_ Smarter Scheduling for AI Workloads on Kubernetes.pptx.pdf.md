\# 《Mind the Topology: Smarter Scheduling for AI Workloads on Kubernetes》PDF总结

\## 一、分享基础信息

\- \*\*分享主题\*\*：Mind the Topology: Smarter Scheduling for AI Workloads on Kubernetes（关注拓扑：Kubernetes上AI工作负载的更智能调度）

\- \*\*分享者\*\*：Roman Baron，NVIDIA高级软件工程师（Senior Software Engineer, Nvidia）

\- \*\*场景\*\*：北美Cloud Native + Kubernetes AI Day（CLOUD NATIVE + KUBERNETES AI DAY NORTH AMERICA）





\## 二、核心问题：为何关注拓扑（Why Topology? Why Now?）

核心背景是\*\*分布式AI工作负载对节点/ Pod拓扑布局高度敏感\*\*，传统调度忽略拓扑差异会导致严重问题，具体体现在两个核心认知上：

1\. \*\*并非所有节点都平等（Not All Nodes Are Equal）\*\*  

&nbsp;  节点归属不同机架（Rack）、可用区（Zone），跨机架/跨可用区的节点间通信延迟更高。例如：

&nbsp;  - 若分布式AI工作负载的Pod被分散部署在Rack 1和Rack 2的随机节点上（如Node 1、Node 5、Node 3、Node 4），会因跨机架通信导致性能损耗；

&nbsp;  - 更优调度应将Pod集中部署在同一机架（如Rack 1的Node 1-4），减少跨机架通信开销。



2\. \*\*并非所有Pod都平等（Not All Pods Are Equal）\*\*  

&nbsp;  分布式AI工作负载中，不同Pod承担不同角色（如领导者、工作节点），角色关联的Pod需就近部署以确保协作效率。若忽略Pod角色差异随机部署，会导致工作负载卡顿（Stuck）或性能降级（Degraded performance）。





\## 三、关键调度技术：Pod亲和性（Pod Affinity）

Pod亲和性是优化拓扑调度的核心手段，目标是\*\*将关联紧密的Pod调度到邻近节点（如同一机架、同一可用区）\*\*，避免“分散部署”的低效问题：

\- 原理：通过配置Pod亲和性规则，指定“某类Pod需与另一类Pod部署在同一拓扑域（如Rack、Zone）”；

\- 效果：例如分布式AI工作负载的Pod通过亲和性规则，被集中调度到Rack 1的Node 1-4，而非分散在Rack 1和Rack 2，显著降低通信延迟，避免性能损耗。





\## 四、典型场景：解耦推理流水线（Disaggregated Inference Pipeline）

PDF以解耦推理流水线为例，说明拓扑调度对复杂AI工作负载的重要性。该流水线包含多类角色Pod，需按角色就近调度：

| Pod角色                | 功能定位                | 调度要求                  |

|------------------------|-------------------------|---------------------------|

| Frontend（前端）       | 接收请求、分发任务      | 需与核心处理Pod邻近        |

| Prefill Leader（预填充领导者） | 协调预填充任务          | 需与Prefill Workers就近部署 |

| Prefill Workers（预填充工作节点） | 执行预填充计算          | 需与Prefill Leader同拓扑域  |

| Decode Leader（解码领导者）   | 协调解码任务            | 需与Decode Workers就近部署  |

| Decode Workers（解码工作节点） | 执行解码计算            | 需与Decode Leader同拓扑域   |

| kv（键值存储组件）     | 存储中间数据            | 需与计算Pod（如Decode Workers）邻近，减少数据读取延迟 |



若忽略角色关联进行随机调度，会导致流水线卡顿（Stuck）；通过拓扑感知调度，可将同角色/关联角色Pod集中部署，确保流水线高效运行。





\## 五、调度方案对比：简单调度 vs 基于KAI的拓扑感知调度

PDF明确对比了两种调度方式的差异，凸显拓扑感知调度的优势：

| 调度类型                | 特点                          | 问题/优势                     |

|-------------------------|-------------------------------|-------------------------------|

| 简单调度（Naive Scheduling Decision） | 忽略拓扑（Zone、Rack），随机部署Pod | Pod分散在Zone 1/2、Rack 1-4，跨域通信延迟高，性能损耗严重 |

| 基于KAI的拓扑感知调度（Topology Aware Scheduling with KAI） | 考虑Zone、Rack拓扑，按角色/关联关系调度Pod | Pod集中在同一Zone（如Zone 1）、同一Rack（如Rack 1-2），通信延迟低，性能最优 |





\## 六、参与与资源：如何获取KAI调度器支持

若需了解或使用KAI拓扑感知调度器，可通过以下渠道参与：

1\. \*\*GitHub仓库\*\*：https://github.com/NVIDIA/KAI-Scheduler（获取源码、文档、Issue反馈）；

2\. \*\*CNCF Slack频道\*\*：#kai-scheduler（实时交流、技术支持）；

3\. \*\*双周会议\*\*：每两周周一17:00 CEST（Central European Summer Time）；

4\. \*\*邮件列表\*\*：https://groups.google.com/g/kai-scheduler（获取更新、订阅动态）。





\## 七、核心结论

\- 分布式AI工作负载的性能高度依赖\*\*拓扑布局\*\*，忽略节点（Rack/Zone）差异和Pod角色差异的调度会导致严重性能问题；

\- \*\*Pod亲和性\*\*是实现拓扑感知调度的关键技术，可将关联Pod集中部署在邻近节点；

\- \*\*KAI调度器\*\*是NVIDIA推出的拓扑感知调度方案，针对Kubernetes AI工作负载优化，支持解耦推理流水线等复杂场景；

\- 开发者可通过GitHub、Slack、邮件列表等渠道参与KAI调度器的使用与协作。

