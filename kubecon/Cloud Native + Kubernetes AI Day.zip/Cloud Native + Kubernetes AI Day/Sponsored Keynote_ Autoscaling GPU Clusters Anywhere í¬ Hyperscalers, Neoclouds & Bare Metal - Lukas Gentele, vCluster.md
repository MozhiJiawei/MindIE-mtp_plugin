https://www.youtube.com/watch?v=LGOELO-ah30



vCluster



视频围绕GPU集群自动扩展展开，介绍了相关问题、解决方案及工具集成等内容，具体如下：

\- \*\*提出工程师获取GPU上Kubernetes访问权限的问题及传统CPU与GPU成本差异\*\*：首先抛出如何让工程团队访问GPU上的Kubernetes这一关键问题，接着对比传统CPU环境，指出CPU资源分配虽有复杂企业流程，但成本较低（如AWS上4核EC2 VM每年约1600美元），而GPU成本高得多，若按传统方式分配GPU易导致成本过高，引出自动扩展的必要性。

\- \*\*介绍vCluster及其特点\*\*：提到vCluster是Kubernetes发行版，可在单个Pod中启动整个Kubernetes集群，也能作为独立二进制文件在VM或裸机上运行，最初作为Pod内发行版旨在快速搭建开发和CI环境并降低成本，同时指出静态添加节点会重回高成本问题，进一步强调自动扩展对vCluster的重要性。

\- \*\*阐述vCluster与Carpenter的集成及vCluster Auto Nodes功能\*\*：说明vCluster近期与开源自动扩展工具Carpenter集成，推出vCluster Auto Nodes功能，将Carpenter直接内置到vCluster中，启动控制平面时会内置Core DNS和Carpenter，且该功能不仅适用于EKS和EC2，还能在多种环境中使用。

\- \*\*讲解Carpenter工作机制及vCluster平台的作用\*\*：指出Carpenter通常需为不同云环境和架构编写提供商，而vCluster平台作为中央集群管理部分，可与节点提供商通信，由节点提供商配置节点并通过kubeadm将其加入集群，同时负责节点全生命周期管理（升级、退役等），Carpenter会通过节点声明优化集群，如调整节点大小、切换提供商以降低成本。

\- \*\*说明基于Terraform和OpenTofu的多环境支持及相关集成\*\*：提到借助Terraform和OpenTofu，vCluster可支持多种云提供商（超大规模云、新云、区域云）、OpenStack、Metal as a service等系统，还能构建混合集群实现云爆发，此外，vCluster还与NVIDIA BCM、Cubeword集成，并在KubeCon上推出在NVIDIA超级Pod（DGX系统）上运行vCluster的参考架构，同时邀请观众获取架构文档、参观展位及参加相关欢乐时光活动。

