\# 《Beyond Chat: Bringing Agents to Kubernetes》PDF总结

\## 一、演讲基础信息

\### 1. 会议与主题

\- 会议：KubeCon CloudNativeCon North America 2025（Cloud Native + Kubernetes AI DAY）

\- 核心主题：突破传统Chat交互，将AI Agent（智能代理）引入Kubernetes，解决基础设施运维效率问题



\### 2. 演讲者信息

| 演讲者 | 所属公司 | 核心职责与领域 | 所属组织 |

|--------|----------|----------------|----------|

| Nimisha Mehta | Confluent | 管理大规模Kubernetes平台 | Cloud Native Artificial Intelligence Working Group（云原生AI工作组） |

| Nina Polshakova | Solo.io | 负责AI Gateway项目 | Cloud Native Artificial Intelligence Working Group；Kubernetes发布团队 |

| 共同兴趣 | - | AI for K8s、容器网络、eBPF、Ingress Gateways、Istio | - |





\## 二、背景：LLM与K8s运维的现状与痛点

\### 1. LLM对开发者效率的影响

\- \*\*OpenAI普及前\*\*：开发者编码需2小时，调试需6小时；

\- \*\*OpenAI普及后\*\*：ChatGPT生成代码仅需5分钟，但调试反而增至24小时（因LLM缺乏基础设施深度可见性）。

\- 核心场景：开发者常依赖LLM（ChatGPT、Claude等）调试代码或K8s基础设施，涉及CNCF项目（如Kubernetes、Argo、Helm、Cilium、Prometheus）。



\### 2. 传统Chatbots的局限性（K8s运维场景）

\- 基础设施运维价值有限，无法深度介入管理；

\- 对实际基础设施的可见性低，难以获取实时状态；

\- 非“云原生”架构，无法适配K8s生态的动态性。

\- 核心疑问：若AI Agent能“安全且声明式”管理基础设施，能否解决上述痛点？





\## 三、核心方案：Kagent介绍

\### 1. Kagent定义与目标

\- 定义：\*\*Kubernetes原生框架\*\*，用于构建、运行和管理AI Agent；

\- 核心特性：声明式（Declarative）、编排（Orchestration）、安全（Security）、可扩展（Scaling）、可观测（Observability）；

\- 目标：让用户在Kubernetes中“轻松且安全地定义和运行AI Agent”。



\### 2. Kagent核心概念

| 概念 | 定义与作用 |

|------|------------|

| Agents（代理） | 由“系统提示（system prompt）+工具/其他代理”组成，与LLM交互实现任务执行 |

| Tools（工具） | 支持本地/远程MCP Server、Agent-to-Agent（A2A）通信（跨代理调用） |

| ModelConfig（模型配置） | 声明式定义需使用的LLM模型（支持OpenAI、Anthropic、Gemini等） |

| User Interaction（用户交互） | 提供Chat UI、CLI两种交互方式，降低使用门槛 |



\### 3. Kagent CRD（自定义资源定义）示例

核心字段与功能（以`sample-agent`为例）：

```yaml

apiVersion: kagent.dev/v1alpha1  # CRD API版本

kind: Agent                      # 资源类型

metadata:

&nbsp; name: sample-agent             # 代理名称

&nbsp; namespace: kagent              # 命名空间

spec:

&nbsp; description: # 代理描述信息

&nbsp; modelConfig: openai-model-config # 关联的LLM模型配置（如OpenAI）

&nbsp; systemMessage: # 系统提示（小提示直接写，大提示通过ConfigMap引用）

&nbsp; tools: # 工具列表（支持内置工具、其他Agent）

&nbsp;   - builtin: # 内置工具（如K8s事件获取）

&nbsp;       name: kagent.tools.k8s.GetEvents

&nbsp;       type: Builtin

&nbsp;   - type: Agent # 引用其他Agent（A2A调用）

&nbsp;       agent:

&nbsp;         name: tools/another-helper-agent # <namespace>/<name>

&nbsp;         kind: Agent

&nbsp;         apiGroup: kagent.dev

&nbsp; a2aConfig: # A2A配置（技能定义）

&nbsp;   skills:

&nbsp;     - description: # 技能描述

&nbsp;       examples: How can I troubleshoot a failing pod? # 示例场景

&nbsp;       id: cluster-diagnostics # 技能ID

&nbsp;       name: Cluster Diagnostics # 技能名称

```



\### 4. Kagent架构（Deep Dive）

\#### （1）核心组件

\- \*\*控制层\*\*：kagent-controller（Go语言实现的控制器，管理Agent生命周期）、Session Service（会话管理与Agent发现）；

\- \*\*交互层\*\*：kagent UI（可视化Chat/编辑）、CLI（命令行交互）、Go HTTPServer（服务支撑）；

\- \*\*资源层\*\*：kagent CRDs（自定义资源）、MCP Server（集群内/外部，工具调用支撑）、Vector DB（向量存储）、Relational Database（会话存储+已发现工具）；

\- \*\*集成层\*\*：LLM（通过ModelConfig关联）、Docs2Vec Tool（文档向量工具）、A2A通信（支持直接服务名调用、部署级调用）。



\#### （2）架构演进

\- 初始设计：基于Microsoft Autogen框架；

\- 当前版本：重构为基于Google Agent Development Kit（ADK），支持多框架（如LangGraph、CrewAI）。



\### 5. Kagent BYO Agent（自定义代理）

\- 功能：支持运行外部开发的自定义Agent，适配个性化场景（如外部系统/API集成）；

\- 核心配置（示例`research-crew`代理）：

&nbsp; - 部署镜像：自定义镜像（如`localhost:5001/research-crew:latest`）；

&nbsp; - 环境变量：通过Secrets注入敏感信息（如`OPENAI\_API\_KEY`、`SERPER\_API\_KEY`）；

&nbsp; - 控制权：用户完全掌控Agent行为、状态与执行流程，Kagent通过A2A协议直接调用。





\## 四、Kagent的差异化优势（vs 其他框架）

1\. \*\*声明式+云原生\*\*：完全适配K8s生态，遵循K8s资源管理范式；

2\. \*\*复杂多代理支持\*\*：支持多Agent协同，适配RBAC、策略规则等K8s安全机制；

3\. \*\*可重复与可分发\*\*：工作流可重复执行，Agent支持版本控制、模板化，易共享；

4\. \*\*事件驱动\*\*：通过`khook`实现Agent事件驱动调用，响应基础设施动态变化；

5\. \*\*CNCF生态集成\*\*：轻松对接CNCF项目（如Cilium Policy调试器、Argo GitOps）；

6\. \*\*低门槛\*\*：支持自然语言构建Agent，无需深度编码。





\## 五、应用案例与集成场景

1\. \*\*GitOps Agent演示\*\*：通过Kagent对接Git仓库（GitHub）、Argo，实现GitOps流程的Agent化管理（如代码读取/写入、微服务Bug调试）；

2\. \*\*Cilium Policy Agent演示\*\*：Agent对接Cilium，调试“前端服务到后端服务的Ingress限制”策略，定位网络访问问题；

3\. \*\*Notion集成\*\*：Agent调用Notion API，获取页面元数据（如“Kagent Demo for Kubecon”页面标题），支持进一步读取内容块；

4\. \*\*Strava数据集成\*\*：Agent获取Strava用户运动数据（如总跑步距离6315.1km、成就11项），实现第三方数据可视化。





\## 六、Kagent最佳实践

1\. \*\*工具设计\*\*：聚焦高价值工具，初始仅配置3-7个高信号工具（避免冗余）；

2\. \*\*Agent选择\*\*：

&nbsp;  - 单Agent：适用于简单、顺序执行的任务；

&nbsp;  - 多Agent：适用于复杂、需协同分工的任务（支持可扩展委托）；

3\. \*\*配置与版本控制\*\*：

&nbsp;  - LLM配置、API密钥存储在ConfigMaps/Secrets（安全隔离）；

&nbsp;  - 版本化Agent Spec，维护工具 schema兼容性；

4\. \*\*提示优化\*\*：

&nbsp;  - 小提示用`systemMessage`，大提示用`systemMessageFrom`（引用ConfigMap）；

&nbsp;  - 按模型优化提示，建立“prompt registry”（提示注册表）；

5\. \*\*模型选择\*\*：非所有任务需昂贵模型，按需选择（平衡成本与效果）。





\## 七、可观测性与安全性

\### 1. 可观测性（针对Agent非确定性特点）

\- 日志与追踪：输出OpenTelemetry日志和追踪数据，关联LLM调用、工具调用、工作流；

\- 嵌套追踪：支持多Agent交互的嵌套追踪，便于定位跨Agent问题；

\- 框架适配：支持LangGraph追踪，提供Jaeger UI可视化（示例：单次追踪耗时5.95s，包含8个Span）。



\### 2. 安全与多租户（依托K8s原生能力）

\- 敏感信息保护：加密Secrets存储API密钥等敏感数据；

\- 权限控制：最小权限RBAC策略，限制Agent操作范围；

\- 网络安全：网络策略（Ingress/Egress）控制流量，服务网格mTLS加密通信；

\- 准入控制：通过OPA/Gatekeeper实现Agent部署准入策略；

\- 资源隔离：命名空间隔离租户，资源配额限制Agent资源占用。





\## 八、社区参与与资源

1\. \*\*社区入口\*\*：https://kagent.dev/community；

2\. \*\*GitHub仓库\*\*：

&nbsp;  - 核心代码：https://github.com/kagent-dev/kagent；

&nbsp;  - 演示代码：https://github.com/nimishamehta5/kubecon2025-kagent-demos；

3\. \*\*活动链接\*\*：MCP和Agents社区派对：https://luma.com/m7zf8dgz；

4\. \*\*CNCF Slack频道\*\*：#toc-artificial-intelligence-initiatives（加入TOC AI倡议，参与讨论）。

