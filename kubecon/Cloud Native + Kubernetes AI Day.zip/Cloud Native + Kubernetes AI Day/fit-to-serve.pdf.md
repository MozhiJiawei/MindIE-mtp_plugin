# 《Fit-to-Serve：动态设备共享新DRA能力在分布式LLM服务中的应用》PDF总结

（基于KubeCon CloudNativeCon North America 2025演讲内容，演讲者：IBM Research的Sunyanan Choochotkaew与Tatsuhiro Chiba）



## 一、背景：分布式LLM推理服务核心框架与需求

### 1\. 核心需求

分布式LLM推理服务需满足**可扩展性（Scalability）、容错性（Fault Tolerance）、可靠性（Reliability）** 三大核心诉求。

### 2\. 关键技术与框架

* **主流推理框架**：vLLM、TGI、llm-d（Kubernetes原生高性能分布式LLM推理框架）
* **核心技术方向**：数据/张量并行（Parallelism）、资源解耦（Disaggregation）、混合专家模型（Mixture of Experts, MoE）
* **llm-d架构流程**：

  1. 客户端发送请求（如`GET /completions`）；
  2. 推理网关（Inference Gateway，符合OAI规范，如Envoy）基于模型名选择`InferencePool`；
  3. 调度器（支持负载/KV/P/D感知路由）根据Pod状态将请求路由至对应副本（如Prefill/Decode变体）；
  4. 缓存层（Shared Prefix Caching如NIXL/DCN、Independent Prefix Caching如LMCache）优化性能；
  5. 自动扩缩容（Autoscaler）基于负载、KV容量、流量混合等数据调整副本数。



## 二、当前设备资源管理的核心痛点

### 1\. Key 1：增加GPU数量不总是有效

* 性能与GPU数量并非正相关：GPU数量增加时，服务性能（请求率`request\_rate`）和每GPU资源使用率会出现波动，并非“GPU越多越好”；
* 需结合**模型架构/大小/优化方式、请求量/速率、SLO预期、推理框架、硬件类型**综合判断GPU需求，无法一概而论。

### 2\. Key 2：GPU利用率普遍偏低

* 据Weights \& Biases（W\&B）数据：**近1/3用户的GPU平均利用率低于15%**，硬件资源浪费严重。

### 3\. Key 3：资源扩展粒度缺乏灵活性

* 现有方案依赖**预配置设备切片**（如NVIDIA MIG，切片类型包括1g.10gb、2g.20gb、7g.80gb等），无法按需分配资源；
* 示例：TinyLLaMA 1.1B模型仅需5% SM（流多处理器）和2Gi内存，却需占用固定MIG切片，导致资源闲置。



## 三、过渡方案：AutoFit（KubeCon NA 2024提出）

### 1\. 核心作用

实现**负载感知的GPU分片**，为LLM推理动态匹配最优GPU资源切片。

### 2\. 工作流程（Webhook机制）

1. 拦截新建Pod的YAML配置；
2. 提取模型特征（如大小、架构）、目标负载、SLO需求；
3. 调用估算器（estimator）计算最优MIG切片配置；
4. 修补Pod的GPU请求（如将`nvidia.com/gpu: 1`修改为`nvidia.com/mig-2g.10gb: 1`）。



## 四、现有设备管理方案的局限

| 方案                | 核心问题                                                                 |
|---------------------|--------------------------------------------------------------------------|
| Device Plugin       | 1. 静态隔离/切片配置，无法动态调整；<br>2. 仅支持均匀资源共享；<br>3. 需依赖二次（智能）调度器 |
| vGPU虚拟化          | 资源分配灵活性不足，无法满足细粒度共享需求                               |



## 五、核心解决方案：DRA与DRAConsumableCapacity

### 1\. DRA（Dynamic Resource Allocation，动态资源分配）基础

* 核心逻辑：将资源分配决策从“节点层面”迁移至“K8s调度器层面”，实现端到端动态管理；
* 三大核心组件：

  * **ResourceSlice**：由硬件提供商（如NVIDIA）定义，描述设备的动态分配能力；
  * **ResourceClaim**：由用户定义，描述具体资源请求（如GPU内存、SM占比）；
  * **K8s调度器**：负责匹配节点、设备与ResourceClaim，完成最终分配。

### 2\. DRAConsumableCapacity（DRA可消耗容量）

* **版本状态**：Kubernetes 1.34引入的Alpha特性，推荐从K8s 1.35开始试用（仍为Alpha）；
* **核心能力**：

  1. 支持**多资源请求的多次分配**：同一设备可同时响应多个ResourceClaim；
  2. 实现**有保障的资源共享**（Consumable Capacity）：明确设备总容量，避免资源超配；

* **典型用例**：

  * vGPU内存分区、带宽限制的网络分配、虚拟网卡（vNIC）共享、I/O带宽智能存储设备共享；

* **配置示例**：

  * ResourceSlice：定义GPU（如gpu0）总内存80Gi，默认请求5Gi，步长1Gi；
  * ResourceClaim：请求30Gi内存，分配后标记“已消耗30Gi”；若后续请求40Gi（剩余50Gi足够）则成功，若请求60Gi（超剩余容量）则失败并尝试下一个设备。



## 六、演示与后续信息

### 1\. 演示（Demo）

基于**vLLM模拟器**和**扩展DRA示例驱动**，部署多规格LLM模型（TinyLlama\_v1.1 1B、Llama-2-7b 7B、opt-13b 13B等），验证DRAConsumableCapacity的动态资源分配效果（如1个GPU同时支持多模型部署，匹配不同SM/内存需求）。

### 2\. 后续参与方式

* **深入讨论会议**：11月11日（周二）2:30 PM - 3:00 PM EST，地点：B406b-407（Atlanta, Georgia），主题《Share With Care：Efficient Device Sharing With Guaranteed Resources Using DRA》；
* **参考资料**：博客《Kubernetes v1.34: DRA Consumable Capacity》（作者：Sunyanan Choochotkaew、Lonel Jouin、John Belamaric）；
* **反馈呼吁**：鼓励试用DRAConsumableCapacity特性并提供反馈，助力功能迭代。
