# 《On-Call the Easy Way With Agents》PDF总结
## 一、基本信息
- **演讲会议**：KubeCon + CloudNativeCon North America 2025
- **演讲者**：Kartikeya Pharasi（Intuit，Staff Software Engineer）、Ryan Tay（Intuit，Software Engineer 2）
- **核心主题**：通过Agent简化Intuit云原生环境下的值班（On-Call）问题排查与解决

## 二、Intuit技术生态与规模（Technology @ Intuit）
### 1. 定位与理念
- 以**云原生开源技术**构建**AI原生开发平台**，致力于打造可扩展工具，并回馈开源社区。
- 核心业务产品：TurboTax（税务）、Credit Karma（信用查询）、QuickBooks（财务软件）、Mailchimp（邮件营销）。

### 2. 关键业务数据
| 维度                | 数据                  |
|---------------------|-----------------------|
| 客户规模            | ~1亿用户              |
| 平台年退税金额      | $1050亿               |
| 平台年管理发票金额  | $2万亿+               |
| QB payroll年支付人数| 1800万美国工作者      |

### 3. 服务网格（Service Mesh）规模
| 维度                | 数据                  |
|---------------------|-----------------------|
| Kubernetes集群数    | 350+                  |
| 日交易 volume       | 160亿+                |
| 部署与滚动更新数    | 1.2万+                |
| 日峰值TPS           | ~29.2万               |


## 三、核心挑战与解决方案（Challenges & Proposed Solution）
### 1. 现有调试挑战（以Istio为例）
- 需筛选海量日志与指标，数据处理压力大；
- 潜在问题多、学习曲线陡峭，难以快速定位根因；
- 即便有完整文档，执行修复步骤仍耗时。

### 2. 解决方案：Agent
- **定义**：可独立执行“观察→分析→决策→解决问题”的程序；
- **核心能力**：
  1. 高容量处理日志；
  2. 关联“观测数据”与“潜在根因”；
  3. 快速执行文档化的操作手册（Runbook）步骤；
- **依赖组件**：Agent Runtime、多生成式AI模型（Generative AI Models）、编排（Orchestration）、工具（Tools）、API/函数、数据库、其他Agent。


## 四、Intuit生成式AI框架：GenOS
- **定位**：Intuit内部“设计、构建、部署生成式AI应用/能力”的标准化路径（Paved Path）；
- **核心功能**：
  - 提供LLM（大语言模型）访问能力；
  - 包含Agents与Tools注册中心；
  - 支持追踪（Tracing）与调试（Debugging）；
  - 具备Agent内存（Agent Memory）管理；
  - 提供Agent效果评估（Agent Evaluation）机制。


## 五、Agent架构与关键组件（Architecture）
### 1. 整体流程与输入输出
- **输入源**：日志（Logs）、指标（Metrics）、告警（Alerts）、变更日志（Changelog）、用户问题描述（User Description）；
- **核心工具**：日志工具、数据查询工具、Chat工具、Kubectl工具、Mesh RAG（检索增强生成）；
- **输出**：问题分析结果、下一步操作建议、工具执行结果。

### 2. Mesh RAG核心逻辑（检索增强生成）
1. **嵌入向量生成**：用户查询（User Query）通过LLM生成嵌入向量（Embedding）；
2. **上下文检索**：向量与“向量数据库（Vector Database）”中的参考文档嵌入向量对比，筛选相关文档片段（Context Chunks）；
3. **增强响应**：LLM结合相关上下文，生成精准回答（Augmented Response）。

### 3. 关键工具示例：MeshRetrieverTool
```python
class MeshRetrieverTool(RetrieverTool):
    name: str = Field("mesh_knowledgebase_retriever", description="Intuit RAG paved path tool which can be used to search any index")
    description: str = Field("This tool helps find relevant help content about Mesh.")
    index_name: str|list[str] = Field("aimga_service_meshdebugdeputymodel", description="The name of the index to search.")
    
    def _run(self, state: RAGInputState, config: RunnableConfig, **kwargs) -> str:
        return super().retrieve_run(state, config, **kwargs)
    
    async def _arun(self, state: RAGInputState, config: RunnableConfig, **kwargs) -> str:
        return await super().aretrieve_arun(state, config, **kwargs)
```

### 4. 常见错误码对照表（Service Mesh调试）
| 短名   | 描述                                                                 |
|--------|----------------------------------------------------------------------|
| UH     | 上游集群无健康主机，且返回503状态码                                  |
| $UF$   | 上游连接失败，且返回503状态码                                        |
| -      | 上游溢出（熔断），且返回503状态码                                    |
| NR     | 无匹配路由（返回404）或下游连接无匹配过滤链                          |
| URX    | 请求被拒绝（HTTP达到上游重试上限，或TCP达到最大连接尝试次数）         |
| NC     | 上游集群未找到                                                       |
| $DT$   | 请求/连接超过max_connection_duration或max_downstream_connection_duration |


## 六、实际案例（Example）
### 1. 问题背景
- **调试ID（txId）**：000cd784-3e46-99a0-b85f-35350ba12ded；
- **K8s信息**：源服务`Intuit.services.gateway.peshtestinbounds`运行于集群`ssharma34-dev4-use2-k8s`、命名空间`services-inboundb82-use2-dev`；
- **问题总结**：目标服务`intuit.services.gateway.peshtesthlacthote`因“无健康上游实例”不可用。

### 2. 下一步操作建议
1. 检查上游服务`intuit.services.gateway.peshtesthlacthote`的健康状态，确认是否有可用实例；
2. 排查Kubernetes集群/命名空间中可能影响服务可用性的问题。

### 3. Agent辅助能力
- 访问Splunk Logs（日志）、Langfuse Trace（追踪）工具；
- 执行指定监控查询、调用消息工具；
- 通过Kubectl工具建议编辑HPA（水平Pod自动扩缩容）或Rollout（滚动更新）配置。


## 七、Agent核心优势（Benefits）
1. **信息汇总与指引**：整合仪表盘、日志、指标、操作手册的信息，直接提供“下一步操作”；
2. **降低学习成本**：应对Istio等复杂系统的高学习曲线，减少人工理解门槛；
3. **持续优化**：从历史数据中学习，提升问题定位与解决精度；
4. **平台扩展支撑**：增强调试能力，助力Intuit云原生平台进一步规模化；
5. **减少重复工作**：降低值班人员的手动调试工作量（Toil）；
6. **提升效率**：缩短问题平均解决时间（MTTR）。


## 八、未来规划（Future）
1. **客户支持集成**：将Agent与客户支持渠道的聊天机器人对接，实现问题“首次处理”；
2. **增强操作能力**：允许Agent执行更具影响力的值班操作（如自动修复低风险问题）。


## 九、补充信息
- **Intuit开源关注**：扫描链接`bit.ly/intuit-oss`，获取开源活动、新闻；
- **展会互动**：访问Intuit展会 booth，了解GitOps Promoter与Numaflow工具。