https://www.youtube.com/watch?v=rwu7JXzbOQ8



视频围绕Whitney Lee借助OpenTelemetry解决AI（Cloud Code）在开发中的“不实”问题展开，介绍了相关工具、案例及OpenTelemetry的价值与挑战，具体如下：

\- \*\*介绍Commit Story应用及功能\*\*：Whitney Lee在Cloud Code帮助下开发了Commit Story，它是一款自动化工程日志应用，专为Cloud Code设计，作为电脑后台代理运行，由Git提交触发，会收集代码变更、提交信息及与Cloud Code的会话对话，自动为每次Git提交生成日志条目，且包含三个AI函数分别负责总结Git提交内容、提取开发对话、排查技术决策及实施情况。

\- \*\*展示OpenTelemetry在应用中的作用（生成系统 diagram）\*\*：Whitney Lee对应用代码库进行了大量OpenTelemetry instrumentation，通过让Cloud Code从控制台日志获取跟踪ID，结合相关日志和指标，生成系统工作 diagram。应用的遥测数据发送到Datadog后端（也可适配其他后端），并利用Datadog MCP工具拉取数据，帮助理解系统中聊天数据的收集和下游日志生成函数的准备过程，且无需查看代码即可了解系统运作。

\- \*\*解释OpenTelemetry的定义与组成\*\*：OpenTelemetry是将系统事件转化为可观测性有用数据的模型，包含多个部分。它是一种规范，有大量markdown文档规定遥测数据中各类信息（如用户ID）的表示方式，确保数据互操作性；包含OTLP（OpenTelemetry协议）；还由三款软件组成，分别是语言特定的OpenTelemetry API（将代码级事件转化为遥测信号）、接收API信息并处理的OpenTelemetry SDK、在数据发送到后端时进行转换的OpenTelemetry Collector。

\- \*\*通过调试案例展示OpenTelemetry的实际价值\*\*：当日志的对话部分生成超时，Cloud Code最初认为是数据模式描述的令牌开销问题，Whitney Lee借助OpenTelemetry验证，发现是原始聊天数据（含大量工具调用）未过滤导致输入过大。进一步通过遥测数据，发现系统已有过滤逻辑，但因新增的多Cloud Code会话分组功能导致过滤被绕过，最终依据遥测数据确认问题并修复，且验证了修复效果。

\- \*\*说明函数 instrumentation 方法\*\*：以日期处理工具函数为例，在函数调用开始时启动跟踪器，结束时停止跟踪器，用于记录函数耗时，还可添加属性，同时将指标和日志与跟踪ID关联，形成系统整体运行情况视图，帮助人类或AI理解系统。

\- \*\*总结开发时使用遥测数据的优势\*\*：包括能反驳Cloud Code的错误假设，避免其陷入错误方向；辅助调试，获取函数输入信息，还可对比历史与当前数据排查问题；为AI提供系统整体视图，避免仅靠关键词搜索和静态代码分析遗漏信息；帮助验证代码变更效果；辅助设计合理解决方案，如根据遥测数据确定日志显示的引用数量。

\- \*\*指出使用遥测数据的不足与未知问题\*\*：未考虑成本，包括遥测数据存储成本及数据传输的令牌消耗，缺乏成本效益分析；Cloud Code对遥测数据也会做出错误假设，虽整体视图可能减少严重错误，但无法完全避免；手动 instrumentation工作量大，虽有自动instrumentation机制及可借助AI代理自动处理，但企业推广仍有难度；未验证如何同时为生产和开发进行instrumentation，虽推测OpenTelemetry的API与SDK分离机制可能实现全量instrumentation但选择性收集数据，但需进一步验证。

\- \*\*互动问答环节（遥测数据查询相关）\*\*：有观众询问如何通过提交历史查找旧遥测数据，Whitney Lee表示无需提交哈希，通过跟踪ID可查询特定跟踪数据，且遥测数据关联日期信息，可按日期范围在Datadog后端查询，如查询三周前的执行数据，但未明确具体查询细节。

