# KServe Next: Advancing Generative AI Model Serving（PDF总结）
## 一、KServe发展历程
| 时间 | 关键里程碑 | 详情 |
|------|------------|------|
| 2019年 | 项目初始（KFServing） | 由Google、IBM、Bloomberg、NVIDIA、Seldon在Kubeflow项目下协作开发，定位为模型推理平台 |
| 2021年 | 品牌升级与独立 | 从KFServing重命名为KServe，成为独立项目；计划当年从Kubeflow项目毕业 |
| 2022年 | 加入基金会 | 正式加入LF AI & Data基金会，成为该基金会的孵化项目，进一步拓展生态 |
| 2025年9月 | 进入CNCF孵化 | 被接受为CNCF（Cloud Native Computing Foundation）孵化项目，标志着其云原生生态地位的提升 |


## 二、KServe核心定义与定位
KServe是**基于Kubernetes的统一AI推理平台**，核心价值的体现在：
- 功能覆盖：同时支持**生成式AI（GenAI）** 和**预测性AI（Predictive AI）** 推理场景；
- 易用性与扩展性平衡：既支持快速部署（满足中小规模需求），也具备企业级能力（应对大规模、高复杂AI workloads）；
- 生态集成：深度融合云原生技术栈（Kubernetes、KEDA、Gateway API等）与硬件加速器（GPU、CPU等）。


## 三、预测性AI vs 生成式AI推理差异
| 维度 | 预测性AI推理 | 生成式AI推理 |
|------|--------------|--------------|
| 核心任务 | 分类（Classification）、回归（Regression） | 生成新数据（文本、图像、代码等） |
| 输入流量 | 小规模、结构化、高并发 | 非结构化（文本/多模态）、流量易突发 |
| 输出流量 | 小规模（单标签/评分） | 大规模、流式输出、高带宽需求 |
| 延迟要求 | 超低延迟 | 中高延迟 |
| 计算/扩缩容 | CPU或L4 GPU（Transformer模型）；水平扩缩容，最大化QPS | H100/H200 GPU（高显存带宽）；需高效利用GPU/VRAM |


## 四、KServe GenAI核心能力与架构
### 1. GenAI关键特性（围绕效率、规模、延迟、成本）
- **LLM基于指标的自动扩缩容**：解决传统并发扩缩容失效问题（传统KPA仅看并发数，忽略GPU VRAM瓶颈）；核心指标包括`KV Cache VRAM使用率`（优先，避免显存满导致无法接请求）、`GPU利用率`（辅助，衡量计算负载）；配置示例：指定目标KV Cache使用率75%，自动调整副本数（1-5个）。
- **Envoy AI网关增强**：
  - 令牌限流（Token Rate Limiting）：从响应体提取令牌使用量，存储到Envoy动态元数据，动态调整限流预算；
  - 推理扩展（Inference Extension）：突破传统负载均衡局限，基于KV Cache使用量、LoRA适配器信息、LLM负载实现“智能端点选择”。
- **llm-d集成**：接入开源分布式LLM推理框架llm-d（支持Kubernetes原生运行），提供：
  - 智能推理调度、前缀缓存（Prefix Caching）；
  - 预填充/解码解耦服务（P/D Disaggregated Serving）；
  - 变体自动扩缩容（Variant Autoscaling）。


### 2. GenAI架构组件
```
[客户端（OpenAI SDK）] → [Envoy AI网关] → [KServe控制器]
                          ↓（核心组件）
        1. 统一API+使用跟踪+智能路由+限流+LLM可观测性
        2. VLLM容器（Head/Worker）+存储容器
        3. KEDA LLM Autoscaler（自动扩缩容）
        4. Model Cache/OCI（模型缓存控制器，支持deepseek/Llama/Qwen等模型）
        5. GPU调度器/DRA（异构GPU集群：H100/H200/A100/MIG）
        6. 模型仓库（GCS/Azure/S3）+分布式KV Cache
```


## 五、LLM推理工作负载类型
### 1. 单节点/多GPU（Single-Node/Multi-GPU）
- 适用场景：小规模模型（SLM，小于70B参数）；
- 配置特点：每个副本对应1个Pod，无分布式并行，部署简单。

### 2. 多节点/多GPU（Multi-Node/Multi-GPU）
- 适用场景：大规模模型（需分布式推理）；
- 配置特点：基于`LeaderWorkerSet`，包含1个Leader Pod（主节点）+N个Worker Pod（工作节点）；支持张量并行（TP）、流水线并行（DP）、数据并行（EP）。

### 3. 解耦预填充/解码（Disaggregated Prefill/Decode）
- 适用场景：高吞吐量需求；
- 配置特点：
  - 预填充池（Prefill Pool）：Leader Pod处理请求、生成KV Cache，支持高并发；
  - 解码池（Decode Pool）：基于KV Cache生成令牌，支持顺序解码。


## 六、LLM推理API设计
### 1. 控制平面API（LLMInferenceService）
| 规格类型 | 核心配置 |
|----------|----------|
| 模型规格（spec.model） | 模型URL、LoRA适配器、存储初始化容器（从HF/S3/PVC下载模型） |
| 路由规格（spec.router） | Gateway API、推理调度器（Scheduler）、HTTPRoute |
| 工作负载规格（spec.template/worker/prefill） | 单节点（Deployment）、多节点（LWS）、预填充-解码（双LWS） |
| 并行性规格（spec.parallelism） | 张量并行（TP）、数据并行（DP）、专家并行（EP） |

### 2. 数据平面能力
- 智能端点选择（Endpoint Picking）；
- 前缀缓存路由（Prefix Cache Routing）；
- 预填充-解码池路由（Prefill-Decode Pool Routing）；
- 负载感知路由（Load-Aware Routing）。


## 七、KServe路线图：统一推理架构（Unified Inference Fabric）
核心目标：
1. 构建**集中式平台**：支持所有开源模型、微调模型、训练后模型的推理服务；
2. 标准化能力：统一API与遥测（Telemetry），确保跨场景一致性；
3. 全托管体验：优化性能与计算资源利用率，降低运维成本；
4. 安全增强：通过SPIFFE/SPIRE实现“Agent-to-LLM”流量的安全身份认证；
5. 网关统一：基于Gateway API整合推理工作负载，打通AI应用与LLM/训练后模型的访问链路。


## 八、社区与行业采用
### 1. 社区规模
- 维护者（Maintainers）：19人；
- 贡献者（Contributors）：300+人；
- 参与方式：
  - GitHub仓库：https://github.com/kserve/kserve；
  - 官网：https://kserve.github.io；
  - 双周会议：每周四9:00 PST；
  - Slack频道：CNCF Slack的#kserve和#kserve-contributors。

### 2. 行业采用者（生产级使用）
- 科技与云厂商：IBM、Red Hat、NVIDIA、AMD、Cisco、Canonical；
- 金融与企业：Bloomberg、Intuit、SAP、Wikimedia、Naver；
- 其他领域：Cloudera、Gojek、Inspur、MaxKelsen、Striveworks、Upstage等。