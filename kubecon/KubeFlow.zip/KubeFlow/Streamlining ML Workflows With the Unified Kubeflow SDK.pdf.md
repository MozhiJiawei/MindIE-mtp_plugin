# Streamlining ML Workflows With the Unified Kubeflow SDK（PDF总结）
## 一、核心目标
解决AI从业者的核心诉求：**通过Python实现AI工作负载的规模化运行**，无需过度依赖底层技术栈（如Kubernetes）知识。


## 二、当前ML工作流的核心挑战
1. **技术门槛高**：需掌握Kubernetes专业知识，对非运维背景的AI从业者不友好；
2. **迭代效率低**：训练、调参等流程周期长，影响模型迭代速度；
3. **API不一致**：Kubeflow现有组件（如kfp、Katib、KServe、Feast）API分散，集成成本高；
4. **版本管理复杂**：模型、数据、训练配置的版本联动难度大，易出现“版本混乱”；
5. **组件协同难**：训练（training）、调参（Katib）、模型注册（model-registry）、部署（KServe）等环节衔接不顺畅。


## 三、Unified Kubeflow SDK核心能力与生态
### 1. 支持的框架与工具
覆盖主流ML/AI技术栈，降低多框架切换成本：
- 模型训练框架：PyTorch、XGBoost、Hugging Face
- 开发工具：Jupyter、JupyterLab
- 底层组件：Kubeflow Katib（调参）、Pipelines（工作流）、Spark Operator（数据处理）、Kubernetes（容器编排）


### 2. 项目状态（截至文档发布时）
| 组件（Component）       | 状态       | 核心功能描述                                                                 |
|-------------------------|------------|------------------------------------------------------------------------------|
| Kubeflow Katib          | 已可用 ✅   | 超参数优化（Hyperparameter Optimization）                                    |
| Kubeflow Pipelines      | 计划中 🚧   | 构建、运行、跟踪AI工作流（端到端流程管理）                                   |
| Kubeflow Model Registry | 计划中 🚧   | 管理模型 artifacts、版本及ML元数据（模型生命周期核心组件）                   |
| Kubeflow Spark Operator | 计划中 🚧   | 管理Spark应用，支持数据处理与特征工程（衔接“数据-训练”环节）                 |


## 四、SDK实际应用演示（核心代码逻辑）
### 1. 模型训练任务（TrainJob）定义与执行
通过`TrainJobTemplate`配置训练参数，支持分布式节点与GPU资源分配：
```python
from kubeflow.trainer import TrainJobTemplate, CustomTrainer, TrainerClient

# 1. 定义训练逻辑（示例：PyTorch训练）
def train_func(lr: float, num_epochs: int):
    import torch
    # 训练逻辑（如模型定义、损失计算）
    outputs = model(inputs)
    print(f"loss={loss.item()}")

# 2. 配置训练模板（100节点，每节点5块GPU）
trainjob_template = TrainJobTemplate(
    trainer=CustomTrainer(func=train_func, func_args={"lr": 0.1, "num_epochs": 5}),
    num_nodes=100,
    resources_per_node={"gpu": 5}
)

# 3. 提交训练任务
TrainerClient().train(**trainjob_template)
```


### 2. 超参数优化任务（OptimizationJob）
基于Katib能力，支持多组实验（Trial）并行运行，指定优化目标：
```python
from kubeflow.optimizer import OptimizerClient, TrialConfig, Search, Objective

# 配置超参数搜索空间与优化目标
optimization_id = OptimizerClient().optimize(
    trial_template=trainjob_template,  # 复用训练模板
    trial_config=TrialConfig(num_trials=10, parallel_trials=2),  # 10组实验，2组并行
    search_space={
        "lr": Search.loguniform(0.01, 0.1),  # 学习率：0.01-0.1对数均匀分布
        "num_epochs": Search.choice([2, 4, 5])  #  epoch数：可选2/4/5
    },
    objectives=[Objective(metric="accuracy", direction="maximize")]  # 目标：最大化准确率
)
```


## 五、SDK支持的两种训练运行时（Runtime）
### 1. 本地运行时（Local Process Runtime）
适合快速调试，无需容器环境：
- 核心特性：
  - 训练任务在本地子进程中运行；
  - 每个任务独立Python虚拟环境（避免依赖冲突）；
  - 仅支持PyTorch runtime、单节点、非隔离GPU；
- 关键代码：
  ```python
  from kubeflow.trainer.backends.container import LocalProcessBackendConfig

  # 初始化本地运行时客户端
  client = TrainerClient(backend_config=LocalProcessBackendConfig(cleanup_venv=True))
  job = client.wait_for_job_status(job_name, status={constants.TRAINJOB_COMPLETE}, timeout=600)
  ```


### 2. 容器运行时（Container Runtime）
适合生产级规模化运行，支持分布式：
- 核心特性：
  - 支持Docker/Podman容器引擎；
  - 多节点分布式训练、GPU支持（需NVIDIA容器工具包）；
  - 每个任务独立网络与DNS（隔离性强）；
- 关键代码：
  ```python
  from kubeflow.trainer.backends.container import ContainerBackendConfig

  # 初始化容器运行时客户端（指定2节点分布式训练）
  client = TrainerClient(backend_config=ContainerBackendConfig(container_runtime="docker"))
  job_name = client.train(trainer=CustomTrainer(...), num_nodes=2)
  ```


## 六、未来路线图（Roadmap）
| 功能方向                  | 具体内容                                  | 关联GitHub Issue       |
|---------------------------|-------------------------------------------|------------------------|
| 文档与工具链              | 搭建Kubeflow SDK官方网站                  | kubeflow/sdk#50        |
| 工作流集成                | 开发Pipelines客户端SDK                     | kubeflow/sdk#125       |
| 数据处理集成              | 开发Spark客户端SDK                        | kubeflow/sdk#107       |
| 模型管理                  | 开发Model Registry客户端SDK                | kubeflow/sdk#59        |
| 本地调优支持              | 实现超参数优化（HPO）的本地执行           | kubeflow/sdk#153       |
| 实验跟踪                  | 集成Model Registry、MLFlow、W&B等工具     | kubeflow/community#892 |
| 训练环境一致性            | 支持训练任务工作目录快照                  | kubeflow/sdk#48        |


## 七、参与方式与资源
### 1. 社区参与渠道
- **CNCF Slack**：加入`#kubeflow-ml-experience`频道；
- **双周会议**：每周三15:00 UTC（协调全球时区）；
- **代码贡献**：参与Kubeflow SDK项目（GitHub：kubeflow/sdk）。

### 2. 联系方式与后续资源
- **演讲者**：
  - Anna Kramar（Email：kramaranya15@gmail.com；GitHub：kramaranya）；
  - Antonin Stefanutti（Email：antonin.stefanutti@gmail.com；GitHub：astefanutti）；
- **后续资源**：官方博客文章、Kubeflow SDK用户调研（获取反馈）。

### 3. 致谢贡献者
andreyvelich、kramaranya、Electronic-Waste、szaher、astefanutti、Fiona-Waters、briangallagher、eoinfennessy、tenzen-y、abhijeet-dhumal等（完整名单见PDF末尾）。