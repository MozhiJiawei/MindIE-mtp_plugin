# Streamline LLM Fine-tuning on Kubernetes with Kubeflow LLM Trainer（PDF总结）
## 一、会议与作者信息
- **会议**：KubeCon CloudNativeCon North America 2025
- **作者**：
  - Andrey Velichkevich（Kubeflow Steering Committee），邮箱：andrey.velichkevich@gmail.com，Github：andreyvelich
  - Shao Wang（Shanghai Jiao Tong University），邮箱：shaowang2002@gmail.com，Github：Electronic-Waste


## 二、核心概念：LLM微调（Fine-Tuning）
1. **定义**：通过“基础模型（如Qwen3）+ 领域特定数据集”训练，得到适配特定场景的“微调模型”。
2. **示例**：
   - 基础模型Qwen3面对问题“What should I do when I catch a cold?”时回答“No ideas”；
   - 经领域数据微调后，可准确回答“Drink some water!”。


## 三、LLM微调的“期望vs现实”
### 1. 期望（Data Scientists视角）
- 简单流程：用PyTorch编写ML代码 → 缩放（Scale）与微调 → 循环迭代。

### 2. 现实（基础设施痛点）
- 需处理大量非业务配置：计算资源（GPU/TPU/NPU）、Docker镜像、数据加载、分布式环境、Gang调度、资源队列；
- 需管理全链路 artifacts：模型/数据集初始化、训练结果导出；
- 形成“编写代码→配置环境→缩放微调”的无尽循环，效率低下。


## 四、用户核心需求（Data Scientists视角）
1. **简单（Simple）**：无需手动编写Kubernetes配置；
2. **灵活（Flexible）**：修改训练脚本时，无需同步修改YAML配置；
3. **可扩展（Scalable）**：依托Kubernetes能力，快速迭代训练想法。


## 五、核心挑战与解决方案
### 挑战1：如何隐藏大量Kubernetes配置
- **痛点**：K8s配置（artifacts管理、调度、安全、资源）不可避免，但数据科学家无需关注；
- **解决方案：面向不同角色的CRDs（自定义资源定义）**：
  - **角色1：K8s管理员**：配置`TrainingRuntime`（定义底层K8s规则），示例：
    ```yaml
    name: torch-distributed-multi-node
    spec:
      mlPolicy:
        numNodes: 2
        torch:
          numGpuPerNode: 5
      template:
        spec:
          replicatedJobs:
            template:
              spec:
                schedulerName: coscheduling
                containers:
                - name: trainer
                  image: docker.io/kubeflow/pytorch-mnist
                  resources:
                    requests:
                      nvidia.com/gpu: 1
                  env:
                  - name: MASTER_PORT
                    value: "29400"
                  command: ["torchrun", "train.py"]
    ```
  - **角色2：数据科学家**：配置`TrainJob`（引用`TrainingRuntime`，仅定义训练参数），示例：
    ```yaml
    apiVersion: trainer.kubeflow.org/v2alpha1
    kind: TrainJob
    metadata:
      name: torch-ddp
      namespace: tenant-alpha
    spec:
      runtimeRef:
        name: torch-distributed-multi-node  # 引用管理员定义的Runtime
      trainer:
        image: docker.io/custom-training
        command: ["torchrun", "train.py"]
        numNodes: 5
        resourcesPerNode:
          requests:
            nvidia.com/gpu: 2
    ```


### 挑战2：如何避免配置变更时重新配置
- **痛点**：微调技术（全量微调、LoRA、知识蒸馏、RL）、分布式策略（DP/TP）、模型/数据集变更时，需重复修改配置；
- **解决方案：BuiltinTrainer（基于TorchTune的LLM Trainer）**：
  1. **核心逻辑**：通过Python SDK封装底层配置，数据科学家仅需关注“模型+数据集+微调参数”；
  2. **工作流**：
     ```mermaid
     graph LR
     A[Data Scientists] --> B[Python SDK配置：模型/数据集/微调参数]
     B --> C[Kubeflow组件：存储初始化器+模型初始化器+数据集初始化器]
     C --> D[从Hugging Face获取资源]
     D --> E[生成TrainJob + JobSet]
     E --> F[TorchTune Trainer执行微调]
     F --> G[模型导出至云存储]
     ```
  3. **依赖组件**：ClusterTrainingRuntime（统一管理集群训练资源）。


## 六、两大核心亮点
### 1. 简化工作流（Streamlined Workflow）
- 数据科学家无需接触K8s细节，仅通过SDK完成“参数配置→资源获取→训练→导出”全链路，流程闭环且自动化。

### 2. 灵活SDK（Flexible SDK）
- **一行启动微调**：
  ```python
  !pip install kubeflow -U
  TrainerClient().train(
    runtime=TrainerClient().get_runtime("torchtune-qwen2.5-1.5b")
  )
  ```
- **灵活调整微调配置**（以QLoRA为例）：
  ```python
  client.train(
    runtime=client.get_runtime(name="torchtune-llama3.2-1b"),
    initializer=Initializer(
      dataset=HuggingFaceDatasetInitializer(storage_uri="hf://tatsu-lab/alpaca/data"),
      model=HuggingFaceModelInitializer(
        access_token="<YOUR_HF_ACCESS>",
        storage_uri="hf://meta-llama/Llama-3.2-1B-Instruct"
      )
    ),
    trainer=BuiltinTrainer(
      config=TorchTuneConfig(
        dataset_preprocess_config=TorchTuneInstructDataset(source=DataFormat.PARQUET),
        peft_config=LoraConfig(
          apply_lora_to_mlp=True,
          lora_attn_modules=["q_proj","k_proj","v_proj","output_proj"],
          quantize_base=True
        ),
        resources_per_node={"gpu": 1}
      )
    )
  )
  ```
- **动态适配能力**：支持平滑切换模型/数据集、微调技术、分布式策略，资源自动分配。


## 七、当前支持的模型
| Runtime Name          | 对应模型                  |
|-----------------------|-------------------------|
| torchtune-llama-3.2-1b | Llama-3.2-1B-Instruct   |
| torchtune-llama-3.2-3b | Llama-3.2-3B-Instruct   |
| torchtune-qwen2.5-1.5b | Qwen2.5-1.5B-Instruct   |
| More Coming Soon…     | -                       |


## 八、下一步计划：动态LLM Trainer框架（#2839）
- **核心目标**：支持动态注册多种Trainer（如unsloth、LLaMA-Factory、torchforge），数据科学家可按需切换；
- **示例代码**：
  ```python
  TrainerClient().train(
    trainer=BuiltinTrainer(
      config=TorchTuneConfig(
        peft_config=LoraConfig(lora_rank=4, lora_alpha=16),
        epochs=4,
        resources_per_node={"gpu": 2}
      )
    ),
    runtime=TrainerClient().get_runtime("torchtune-qwen2.5-1.5b")
  )
  ```


## 九、参与方式
- **加入工作组**：Kubeflow AutoML and Training WG；
- **社区渠道**：
  - CNCF Slack：#kubeflow-trainer频道；
  - 双周会议：每周三2pm UTC、每周三5pm UTC。