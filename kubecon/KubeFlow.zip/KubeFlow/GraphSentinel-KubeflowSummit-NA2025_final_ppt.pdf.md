# GraphSentinel 技术方案总结（Kubeflow Summit NA 2025）
## 一、项目背景与动机（WHY）
核心解决**AI驱动的网络安全威胁检测与响应痛点**，具体需求如下：
1. **AI加速的威胁演变**：威胁迭代速度快，需更低噪声、更快速的检测能力，且需提供人类可理解的上下文解释。
2. **边缘优先的动态系统需求**：实现“边缘检测-中心富集-边缘回推”的闭环，支持混合智能流（Edge→Cloud：Detect→Enrich→Respond）。
3. **自动化困境**：需通过AI提升自动化水平，提供以人为中心的决策支持，基于知识图谱（KG）降低告警疲劳。


## 二、GraphSentinel 四大核心目标
| 目标类别 | 核心问题 | 解决方案 |
|----------|----------|----------|
| 警报疲劳解决方案 | Falco生成大量冗余警报（单次攻击触发50+事件） | 将50+事件聚合为1个有效检测结果，降低噪声 |
| 隐私优先架构 | 敏感数据需本地留存 | 采用联邦学习：边缘侧数据不流出，仅向中心共享模型权重 |
| 上下文感知AI | 难以区分正常行为与真实攻击 | 基于图神经网络（GNN）分析事件关联（文件+网络连接），输出攻击/正常判定 |
| 可扩展运营 | 需支持100+边缘节点的MLOps生命周期 | 基于Kubeflow编排，实现“无Kubeflow则无法完成”的规模化部署 |


## 三、核心技术流程（WHAT：Graph RAG 智能流）
1. **异常识别**：GNN从Falco日志/集群日志中标记异常，输出风险分数+标签。
2. **上下文查询**：GraphRAG查询MITRE ATT&CK知识图谱（基于Neo4j+嵌入向量），获取威胁上下文。
3. **解释与行动生成**：vLLM生成简洁的威胁解释与建议响应动作，集成SME（领域专家）Agent辅助决策。
4. **工具链支撑**：含CYPHER语句增强、LLM提示工程、Agent记忆、EDA自动化、Chat GUI等模块。


## 四、选择Kubeflow的原因
### 1. 初始痛点（无Kubeflow时的风险）
- **训练风险**：依赖手动脚本，仅支持单机器运行。
- **部署风险**：手动SSH登录边缘节点，易出错且无法规模化。
- **监控缺口**：无模型版本控制，无法追踪“哪个模型运行于哪个节点”。
- **协作风险**：版本冲突频发， Notebook与实验数据易丢失。

### 2. Kubeflow核心优势
- **开源无锁死**：零成本、无厂商绑定，生产级就绪。
- **工业化MLOps**：从Day1支持全生命周期管理，聚焦模型创新而非基础设施运维。


## 五、Kubeflow核心模块与应用
| Kubeflow组件 | 核心功能 | 应用价值 |
|--------------|----------|----------|
| Kubeflow Pipelines | 编排ML全生命周期 | 全流程可复现、版本化 |
| JupyterHub | 协作开发环境 | 团队聚焦ML创新，避免重复工作 |
| MinIO | 分布式模型/数据存储 | 支持端到端自动化 workflow |
| KServe | 模型服务（含自动扩缩容） | 可扩展至100+边缘节点 |
| Katib | 超参数优化 | 零厂商绑定，提升模型性能 |
| Dex + Keycloak | 企业级认证 | 从Day1满足生产级安全需求 |
| 自定义Docker Registry | 容器版本控制 | 确保部署一致性 |


## 六、架构设计
### 1. 中心-边缘AI架构
| 层级 | 核心组件 | 功能 |
|------|----------|------|
| 中心集群（Kubeflow Cluster） | Keycloak、Kubeflow Pipelines、JupyterHub、Katib、Dex、KServe、MinIO | 模型训练、编排、存储、认证、服务部署 |
| 边缘集群（Edge Cluster） | Falco、Sidekick、Message Queue（NATS）、Knative、本地MinIO、Harbor | 实时事件检测、Serverless处理、本地推理、数据暂存 |

### 2. 边缘侧流程（延迟<100ms）
1. **事件采集**：Falco生成安全事件 → Sidekick转发 → NATS队列缓冲。
2. **触发与处理**：Knative Trigger触发Serverless处理（按需分配资源）→ 加载ONNX模型构建图 → GNN推理（风险评分）。
3. **数据流转**：Loki+Grafana监控 → Log Writer存储 → 边缘MinIO与中心MinIO同步数据。


## 七、技术栈详情（HOW）
### 1. 核心技术分类
| 技术领域 | 具体组件 |
|----------|----------|
| 核心Kubeflow | Kubeflow Pipelines、KServe/Seldon、Katib（AutoML）、MLflow Registry、MinIO |
| ML/AI框架 | PyTorch+PyG（图神经网络）、ONNX Runtime、vLLM/LLM、Sentence Transformers、LangChain/LangGraph |
| 数据与KG存储 | Neo4j（STIX 2.1格式）、MinIO/S3、Qdrant/Weaviate（向量数据库） |
| 安全工具 | MITRE ATT&CK（威胁框架）、Falco（运行时安全）、RBAC+网络策略、Sealed Secrets |

### 2. 边缘vs云部署对比
| 组件 | 边缘部署 | 云部署 |
|------|----------|--------|
| vLLM模型 | Llama-2-7B（4-bit，~4GB） | Llama-2-70B（多GPU） |
| 向量数据库 | ChromaDB（嵌入式） | Qdrant（分布式） |
| Neo4j知识图谱 | 子集（~500MB） | 完整版（~5GB） |
| 延迟 | <100ms | 200-500ms |
| 硬件 | Jetson AGX/边缘GPU | K8s集群（4x A100 GPUs） |


## 八、挑战与Kubeflow解决方案
| 挑战 | 优化前状态 | Kubeflow解决方案 |
|------|------------|------------------|
| 依赖地狱 | “仅在我机器上能运行” | 组件容器化，统一依赖环境 |
| 规模管理 | 手动SSH管理100+边缘节点 | 自动化Pipeline部署，批量管控 |
| 可复现性 | Notebook与实验数据丢失 | Git版本化Pipeline，全流程追踪 |
| 团队协作 | 工作孤岛，信息割裂 | JupyterHub协作环境+用户配置 |
| 模型漂移 | 模型性能退化未检测 | 自动化监控+定时重训练Pipeline |


## 九、GraphRAG Agent 设计
### 1. 边缘部署（实时响应）
- **用例**：实时本地异常响应、低延迟需求（<100ms）、网络隔离环境、IoT安全。
- **组件**：轻量化vLLM（4-bit量化）、本地Neo4j子集、嵌入式ChromaDB、精简MITRE KG。
- **通知方式**：本地syslog告警、SNMP陷阱至SIEM、边缘仪表盘更新， critical事件触发云升级。

### 2. 云部署（全局分析）
- **用例**：多租户安全分析、历史模式识别、高级威胁关联、企业级报告。
- **组件**：GPU支撑的vLLM集群、完整Neo4j MITRE KG、分布式Qdrant/Weaviate、全量ATT&CK+CTI feeds。
- **通知方式**：邮件/SMS至安全团队、Slack/Teams集成、SOAR平台触发、高管仪表盘。


## 十、演示与实验结果
1. **Pipeline执行阶段**：数据初始化（2min）→ 预处理（1min）→ 图构建（30s）→ GNN训练（3min）。
2. **Katib超参优化**：20组并行实验，最佳F1分数0.988，最优参数：learning_rate=0.01、hidden_channels=128。


## 十一、经验教训
1. **优先搭建平台**：基础设施先行，再聚焦ML模型（“Infrastructure first, ML second”）。
2. **全面容器化**：所有组件、依赖均容器化，避免环境差异。
3. **从Day1监控**：“无法衡量则无法优化”，全链路埋点监控。
4. **尽早自动化**：手动流程无法规模化，优先自动化重复操作。
5. **重视协作工具**：JupyterHub+用户配置是团队效率关键。
6. **组件先测试**：孤立测试组件后再集成Pipeline，降低调试难度。


## 十二、未来路线图（2026-2027）
- **Q1 2026**：联邦学习v2（无中心数据收集）。
- **Q2 2026**：GraphRAG集成（上下文感知威胁分析）。
- **Q3 2026**：多云支持（AWS、Azure、GCP）。
- **Q4 2026**：AutoML神经架构搜索。
- **Q1 2027**：实时流处理（微秒级延迟）。


## 十三、关键收获与资源
### 1. 核心收获
- Kubeflow支持1→100+节点无缝扩展；
- Pipeline是MLOps的基础，需优先搭建；
- 早期集成安全（Keycloak+Dex），避免后期改造；
- MinIO复制解决分布式存储同步问题；
- 监控需“内置”而非“外挂”；
- Kubeflow生态成熟，当前已具备生产级能力。

### 2. 资源链接
- Pipeline模板：[github.com/secopsplus/graphsentinel/pipeline](github.com/secopsplus/graphsentinel/pipeline)
- 边缘部署工具：[github.com/secopsplus/graphsentinel/edge](github.com/secopsplus/graphsentinel/edge)
- 文档：[github.com/secopsplus/graphsentinel/docs](github.com/secopsplus/graphsentinel/docs)
- 联系人：Mustafa DAYIOGLU（mustafa.dayioglu@gmail.com）、Zeyno AYGEN DODD（trezbit@conjectura.net）