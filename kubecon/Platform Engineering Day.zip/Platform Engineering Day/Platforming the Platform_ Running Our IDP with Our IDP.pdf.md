# PDF总结：Platforming the Platform: Running Our IDP with Our IDP


## 一、核心背景与演讲者
- **演讲者**：
  - Andrew Sail：Spotify Portal的SRE与基础设施工程经理
  - Laurén Roshore：Spotify可观测性（Observability）工程经理
- **两人工作时间线**：
  1. 2020年：Andrew加入Spotify，两人为SRE同事
  2. 2021年：Laurén成为Spotify可观测性团队经理，同时是Andrew的上级
  3. 2022年：Andrew晋升为同级经理
  4. 2023年：Andrew离开SRE领域，转入数据平台团队
  5. 2025年：Andrew加入Backstage组织，管理全新SRE团队（演讲当下背景）


## 二、听众预期收获
1. 可复用、无平台依赖的**指导原则**：用于构建能改善工程师日常工作的平台
2. 可量化的**成功案例**：平台化、碎片化消除、标准化领域的实践成果
3. 三大核心**案例研究方向**：
   - 组织文化转变
   - 最佳实践如何提升工程师满意度
   - 改善平均修复时间（MTTR）并达成服务级别协议（SLA）


## 三、Spotify面临的核心挑战：规模化难题
Spotify在平台规模化过程中面临三大关键问题：
- **碎片化（Fragmentation）**：引发混乱与技术债，增加成本，阻碍内部人才流动
- **认知过载（Cognitive Overload）**：导致工程师疲劳、焦虑，降低工作满意度与生产力
- **运营风险（Operational Risk）**：缺乏最佳实践及推广该实践的组织文化，导致风险升高


## 四、初期组织策略（Spotify-green-field Day 1）
针对规模化难题，团队从三方面制定初期策略，且初期无指标、无告警、无服务级别体系，核心思路是“复用最优资源而非重建”：
1. **战略伙伴关系**：观察客户与兄弟团队，与销售、客服、产品团队建立合作
2. **组建团队**：培养现有SRE人才、招聘新SRE、培育“自助式平台文化”
3. **优先处理技术债**：识别影响最大的痛点、按优先级排序并执行；复用现有资源实现新业务线的运营


## 五、平台构建的指导原则
1. **控制混乱（Control the Chaos）**：实施“护栏”而非“障碍”，明确所有权以减少意外情况
2. **一致性（Consistency）**：建立通用模式、统一开发者体验、共享语言与工具，且基于可复用组件构建
3. **标准化黄金技术（Standardized, Golden Technologies）**：聚焦“精选技术栈”与“黄金路径”，推动技术进化而非碎片化


## 六、可观测性栈（Observability Stack）实施
- **核心定位**：基于开放标准构建的“统一可观测性栈”，适配所有产品
- **关键组件**：IDP Spotify Infro、Instance IDP（含OTLP push如Victoria Metrics、serape Collector OTel）、VMAgent、IDP scrape/pysh、Instance PubSub Exporter Collector OTel、PubSub Receiver、PubSub、Google GCP Metrics


## 七、实施影响（5周内成果）
1. 事件/严重事件（SEV）的**MTTR降低超50%**（可观测性平台上线后首月）
2. 上线**5个全新Portal功能**，且从初始阶段就配置了关键指标与告警
3. 达成SLA且平台稳定可靠，直接提升客户满意度
4. 强化“从事件中学习”的文化：通过工具集推动有意义、易实施的问题修复方案


## 八、关键收获（Key Takeaways）
1. 共享平台工具可提升跨团队同理心
2. 通用标准能降低MTTR并提升平台可靠性
3. 跨组织“自食其果”（Dogfooding，即平台团队使用自身构建的平台）：带来更丰富的默认配置与更快的迭代速度
4. 统一反馈循环可同时强化平台团队与产品团队
5. 最核心建议：**JUST DO IT!**（快速行动，落地实践）


## 九、下一步计划（What’s Next）
1. 优化告警以减少噪音
2. 实现端到端追踪
3. 开发自动埋点（Auto-instrumentation）与采样护栏
4. 落地异常检测与AI分类功能