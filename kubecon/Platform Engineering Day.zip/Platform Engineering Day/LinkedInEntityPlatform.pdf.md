# LinkedIn Entity Platform 总结报告
**分享背景**  
- 时间：2025年11月 Platform Engineering Day  
- 分享人：Banu Muthukumar（Staff Software Engineer）、Siddharth Shah（Sr. Staff Software Engineer）  
- 核心主题：LinkedIn Entity Platform 的背景、建设目标与落地成果  


## 一、平台背景：现状与挑战
### 1. 核心实体规模（LinkedIn生态基础）
- 会员（Members）：12亿  
- 公司（Companies）：6900万  
- 职位（Jobs）：1500万  
- 技能（Skills）：4.2万  
- 院校（Schools）：14.1万  
- 帖子（Posts）：190亿  

### 2. 原有架构与效率瓶颈
- **原架构**：采用微服务架构，包含 API Gateway、Member Profile Service、Companies Service、Jobs Service、Skills Service 等模块，各服务对应独立数据库（DB）。  
- **核心瓶颈**：效率低下，上线周期长  
  - 实体（Entities）上线：需**数月**  
  - 查询（Queries）上线：需**数周**  


## 二、平台前提：建设目标与核心定位
### 1. 核心目标：效率跃迁
- 实体上线周期：从“数月”缩短至“数天”  
- 查询上线周期：从“数周”缩短至“数小时”  

### 2. 能力支撑
- 支持AI应用：引入 Semantic Kernel，赋能生成式AI、AI软件开发等场景（如“Certification Entity”证书实体的技能关联）。  
- 核心组件：覆盖 Platform Privacy（隐私）、ACL Platform（权限）、Metadata Platform（元数据）、Quota Platform（配额）等，支撑“在线+近线+离线”三类消费者需求。  


## 三、平台建设：实施路径与关键成果
### 1. 分阶段实施计划（时间线）
| 阶段       | 时间范围   | 执行团队       | 核心任务与成果                          |
|------------|------------|----------------|-----------------------------------------|
| 启动期     | 第1-6个月  | Tiger Team     | 定义愿景、获取资源支持、构建POC（原型） |
| V1发布期   | 第6-12个月 | Tiger Team     | 发布MVP版本：2个索引实体，200 QPS       |
| 扩展期     | 第12-18个月| -              | 30个索引实体，40万 QPS；启动托管体验建设 |

### 2. 核心技术架构
- 数据流转：基于 **SoT DB（单一数据源）**，通过 **CDC Stream（变更数据捕获流）** 同步至 Entity Service  
- 查询能力：支持 **Declarative Query（声明式查询）**，搭配多索引系统（Index System 1/2/3 + Global Entity Index）及 SQL DB、Graph DB  
- 实体管理：新增 **Managed Entity Service**，统一管理 Schema/Metadata/Configurations（ schema/元数据/配置）  

### 3. 推广与保障策略
- 驱动原则：“UX drives Velocity”（用户体验驱动效率），覆盖平台所有者、实体所有者、查询创作者三类角色  
-  adoption 激励：提供“最新技术+零迁移成本”，不改变现有系统状态，同步保障数据连通性、可观测性、合规性  
- 合作模式：与客户伙伴、基建伙伴、同行平台所有者建立互利合作关系  

### 4. 当前成果（截至分享时）
- 性能：QPS 达 **180万+**  
- 实体：已落地 **8个托管实体**，且数量持续增长  
- 架构：成功上线 **新索引系统**  


**标注**：本报告内容基于 LinkedIn 内部 proprietary 文档，所有数据与技术细节均为文档披露信息。