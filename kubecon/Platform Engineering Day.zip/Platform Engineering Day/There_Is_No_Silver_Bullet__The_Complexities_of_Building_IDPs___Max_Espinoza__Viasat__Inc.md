# 构建内部开发平台（IDP）：无万能解决方案与核心复杂性总结
## 一、演讲者与主题概述
- **演讲者**：Max Espinoza（Viasat 高级平台架构师），9+年行业经验，曾构建内部应用平台，现主导新IDP建设，兼具历史爱好者与水彩新手身份。
- **核心主题**：There Is No Silver Bullet（构建IDP无“万能解决方案”），聚焦IDP建设的复杂性与实践要点。
- **内容框架**：从“IDP定义”到“现实案例”，再到“五大核心复杂性”，最终落地“实践总结”，逻辑闭环覆盖IDP全生命周期关键环节。


## 二、什么是IDP？（参考架构）
基于平台工程的IDP架构模板，结合AWS Cloud与Backstage工具链，核心组件分为6层，形成“从代码到运维”的全链路支持：
| 架构层          | 核心组件                                                                 |
|-----------------|--------------------------------------------------------------------------|
| 代码与版本控制  | GitHub（应用源码）、Platform Source Code（平台源码）、Score（工作负载定义） |
| CI/CD流水线     | Terraform Automations（基础设施即代码自动化）、CI Pipeline（持续集成）       |
| 资源层          | 计算（K8s相关组件）、数据（未明确具体存储）、Argo CD（持续部署）           |
| 可观测性层      | Monitoring and Logging Plane（监控日志层）、Prometheus/Grafana（观测工具） |
| 网络与服务      | Route 53（DNS服务）、Networking（网络配置）                               |
| 安全层          | HCP Vault（密钥管理）、Security Plane（安全管控）                         |


## 三、现实世界的IDP：Viasat案例
Viasat基于自身需求修改IDP架构，适配2000名工程师的产品交付需求，核心组件与功能如下：
1. **入口与目录层**：Service Catalog/API Catalog（服务/API目录），基于Backstage + SAP LeanIX构建，提供资产发现能力。
2. **代码与交付链路**：
   - 版本控制：Visual Studio Code（开发工具）、GitHub（代码托管）；
   - 流水线：Terraform（IaC）、JFrog Artifactory（制品仓库）、Argo CD（CD流水线）；
   - 资源层：AWS计算资源、AWS S3（数据存储）。
3. **可观测性与成本管控**：
   - 监控工具：Prometheus（指标采集）、Grafana（可视化）、OpenSearch（日志分析）；
   - 成本管理：Kubecost（多集群成本监控，含Namespace级成本明细，如Namespace A $276、Namespace E $307.32）。
4. **网络与安全**：
   - 网络：Route 53（DNS）、Cilium（服务网格与网络策略）；
   - 安全：HCP Vault（密钥存储）、Amazon Secrets & Identity Manager（身份与密钥管理）。
5. **文档与自助支持**：Backstage TechDocs（Markdown文档渲染，支持搜索），覆盖“入职指南、使用手册、故障排除”等开发者需求。


## 四、IDP建设的五大核心复杂性
### 1. 服务网格选择：功能与需求的平衡
核心矛盾：高级服务网格的“认知负载”与“实际功能使用率”不匹配，需基于当前需求选择（以Istio vs Cilium为例）：
| 需求场景          | Istio（Sidecar模式）                | Cilium（eBPF驱动）                  |
|-------------------|-------------------------------------|-------------------------------------|
| 入口管理          | Ingress Gateway + Virtual Services  | Gateway API（HTTPRoutes & Gateway） |
| Pod间加密         | mTLS                                | WireGuard（轻量级加密）             |
| 遥测能力          | Telemetry（内置遥测）               | Hubble Metrics（eBPF级指标）        |
| 网格可视化        | Kiali                               | Hubble（原生可视化）                |
| 认证授权          | RequestAuthentication + AuthorizationPolicy | K8s GEP-1494 + Cilium CFP: #23797   |
| 集群间网格        | Multicluster（多集群支持）          | Cluster Mesh（集群网格）            |

- **补充实践**：AWS EKS环境下需搭配AWS WAF（防护）、AWS ELB（ALB，负载均衡）；Cilium需配置关键Helm参数（如`gatewayAPI.hostNetwork.enabled`控制Envoy监听地址、`kubeProxyReplacementHealthzBindAddr`启用健康检查），同时明确IDP管理员与用户的IaC职责分离。


### 2. 内部共享所有权：从“自助服务”到“隐性SRE”
核心逻辑：**自助服务 + 默认运维期望 = 事实上的SRE职责**，需通过3个关键动作实现权责平衡：
- **运维标准化**：默认提供监控/告警（基于Helm的告警抽象，如Slack渠道配置存储于Vault，支持自定义告警优先级）、全局成本可见性（Kubecost仪表盘）；
- **文档自助化**：Backstage TechDocs提供“开发者友好”文档，覆盖：
  - 受众：IDP开发者与终端用户；
  - 内容：功能使用指南、常见任务教程、架构设计记录、最佳实践、故障排除手册；
- **协作透明化**：通过“Customer Responsibility Matrix（客户责任矩阵）”明确平台与业务团队的权责边界，减少推诿。


### 3. 集中化选择：多集群管理的“效率与成本博弈”
因需管理多集群，IDP需在“完全去中心化”与“集中化”之间做取舍，两种模式对比及实践结论如下：
| 模式                | 架构特点                                                                 | 优势                                  | 挑战                                  |
|---------------------|--------------------------------------------------------------------------|---------------------------------------|---------------------------------------|
| 完全去中心化        | 每个集群（Cluster1~ClusterN）均部署ArgoCD、Prometheus、Grafana、Kubecost | 集群独立，故障隔离性强                | 资源重复浪费、无全局视图、维护成本高  |
| 集中化（Viasat选择）| 1个“工具集群”（托管ArgoCD、AMP、Grafana）+ N个“业务集群”（部署Alloy、Kubecost） | 1. 提供IDP全局服务视图；2. 降低资源成本 | 1. 新集群注册需手动操作；2. AMP告警设置复杂 |

- **核心结论**：集中化更适配“多集群规模化管理”，但需提前解决“手动操作瓶颈”与“告警配置复杂度”问题。


### 4.  Poor UX → 高支持成本：开发者体验的隐性影响
- **核心矛盾**：IDP复杂度高 + 开发者对“自助服务”的期望 → 支持需求激增（即使有文档，开发者仍需指导）。
- **缓解手段**：
  - 工具优化：用Backstage“软件模板+启动套件”替代传统文档，例如“应用入职模板”支持“输入参数→验证配置→执行部署”全流程可视化，降低操作门槛；
  - 对比改进：旧平台仅依赖静态文档，新IDP通过Backstage模板将“入职流程”从“读文档→手动操作”简化为“模板引导→自动执行”，支持需求下降30%+（隐含数据）。


### 5.  Getting Started：启动阶段的“信任建立难题”
- **核心挑战**：IDP是“重投入、慢回报”项目，初期易因“看不到即时价值”导致业务团队信任降低。
- **破局策略**：
  1. **优先核心服务**：启动阶段聚焦“高杠杆组件”，避免全面铺开——优先建设ArgoCD（CD）、GHA Runner（CI执行）、EKS集群 provisioning（基础设施）、TF流水线（IaC）、Backstage（入口）；
  2. **量化价值传递**：通过“时间节省对比”（如旧流程部署需2天，IDP仅需2小时）清晰传达收益；
  3. **跟踪开发者体验**：建立DX（Developer Experience）指标（如Score 64的案例），持续优化平台易用性；
  4. **投资基础组件**：前期投入时间打磨“稳定、易用的基础层”，为后期规模化铺路。


## 五、核心总结要点
1. **IDP不是“开箱即用”**：构建IDP≠托管服务或购买现成方案，需结合“工具链、组织流程、开发者需求”做深度整合；
2. **需求驱动定制**：所有技术选择（如服务网格、集中化模式）必须适配“当前组织的规模、团队能力、业务场景”，无“通用最佳实践”；
3. **以人为核心**：IDP的终极目标是“提升开发者体验”，需始终记住“开发者是人”——降低认知负载、简化操作流程、传递明确价值，比“技术先进性”更重要。


## 六、致谢与联系
- 致谢对象：Viasat同事、Nano Banana（图片支持）、CNCF社区、Platform Engineering Day；
- 联系渠道：https://readthinkhack.org（可通过该链接与演讲者深入交流）。