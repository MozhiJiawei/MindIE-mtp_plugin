# 《Platform Engineering Is the Key Lever for Sustainable Cloud Infrastructure》PDF总结
## 一、演讲者背景
| 姓名 | 关键身份与贡献 |
|------|----------------|
| Nancy Chauhan | - 现任Agno工程师（Eng @Agno）<br>- CNCF（云原生计算基金会）大使<br>- “Women in Cloud Native”社区创始人<br>- 2024年CNCF可持续发展周负责人<br>- 原TAG Environment Sustainability联合主席（现重组为TAG Operational Resilience）<br>- 个人网站：nancychauhan.com |
| Ramiro Berrelleza | - Okteto创始人<br>- 专注领域：开发者工具、开源、创业公司<br>- 社交账号：多数平台使用@rberrelleza<br>- 个人网站：ramiroberrelleza.com |


## 二、IT行业可持续性核心现状与问题
### 1. 碳排放与能源消耗数据
- 当前IT行业占**全球碳排放的2%** ，保守预计未来几年维持1-2%，到2040年可能升至12%。
- 数据中心占**全球电力使用的比例超2%** ，且AI需求每月持续推高这一占比。

### 2. 关键挑战
- 社区因资源压力抵制新建数据中心。
- 微软等企业面临“电力不足，无法安装全部GPU”的困境。
- 无限制的计算资源增长模式已不可持续。


## 三、经济现实与核心逻辑
### 1. 成本与可持续性的关联
- 云账单已成为“董事会级议题”，可持续性与成本优化是“同一枚硬币的两面”。
- 核心激励模型：**省钱→省能源→拯救地球**，需从“为美德环保（green for virtue）”转向“为利润环保（green for profit）”。

### 2. “LED教训”的启示
- 回收运动因未兼顾多方利益难以规模化，而LED灯泡成功的核心是“各方受益”：对消费者更便宜、对制造商更盈利、对社会碳排放更低。
- 核心结论：需将LED的“多方共赢”逻辑套用在云基础设施优化中。


## 四、平台工程（Platform Engineering）的核心价值
### 1. 平台工程的关键作用
- 控制现代软件的“运行时（runtime）”，主导三大核心决策：设定默认配置、提供“黄金路径（golden paths）”、定义效率标准。
- 每一项决策（如多租户架构、自动扩缩容、采用ARM架构）均直接影响能源消耗，是实现“系统性可持续性”的核心杠杆点。

### 2. 实战案例：Okteto + 金融客户
- 优化动作：从AMD架构迁移至EKS（Elastic Kubernetes Service）上的ARM架构，平台团队仅需搭建ARM集群+适配开发者工具，无需修改应用代码。
- 最终成果：**云账单降低40%** ，碳足迹同步减小；实现“性能↑、能源消耗↓、成本↓”的三重优化。


## 五、有效的平台工程实践模式
1. **智能自动扩缩容**：基于实际资源使用量调整，而非“猜测峰值”。
2. **默认ARM镜像**：针对无状态工作负载，默认采用更节能的ARM架构镜像。
3. **节能区域调度**：将工作负载调度至能源效率更高的区域。
4. **临时环境自清理**：空闲时自动删除临时环境，避免资源闲置。
5. **能源可观测性**：在可观测性指标中纳入“能源消耗信号”，实时监控能耗。


## 六、AI工作负载的可持续性优化
### 1. AI的能耗痛点
- AI工作负载使能源消耗“呈指数级增长”，且GPU存在三大问题：资源稀缺、成本高昂、更新迭代快（易过时）。

### 2. 平台团队的AI能效杠杆
- 即时分配（Allocate just-in-time）：避免GPU长期闲置。
- 空闲会话关闭（Shutdown idle sessions）：及时释放未使用的GPU资源。
- 能源成本监控（Monitor per-job energy cost）：追踪每一项AI任务的能源消耗。


## 七、上下文工程（Context Engineering）与平台工程的结合
### 1. 核心原则：效率即可持续性
- 多余的CPU周期、冗余的AI Token，均属于“浪费的能源”；需通过“合理调整集群大小→合理调整提示词（prompts）”实现精准化。
- AI可持续性的关键：非“克制使用（abstinence）”，而是“精准使用（precision）”；平台系统与AI系统的共同目标是“有意极简设计（intentional minimalism）”。

### 2. 具体优化措施
-  Token instrumentation：在可观测栈中记录并可视化“每一次智能体（agent）运行的Token成本”。
- 任务特定模型：避免用GPT-4级模型处理简单任务（如分类、路由），选择轻量模型。
- 上下文限制：将聊天/运行历史限制在3-5轮，而非保留完整日志。
- 静态提示缓存：复用智能体指令，避免重复生成。


## 八、激励机制与行动步骤
### 1. 财务与环境双重激励
- 能源节省直接降低云账单（每节省1kWh即减少成本）。
- 平台预算开始纳入“能源效率KPI”，可持续性报告整合至可观测面板。
- 演进路径：从FinOps（财务运维）→GreenOps（绿色运维）→Sustainable Ops（可持续运维）。

### 2. 可立即启动的行动（You Can Start Tomorrow）
1. 基准测试：对比ARM与x86集群的能效差异。
2. 指标接入：将能源指标添加到Prometheus（监控系统）和Grafana（可视化工具）。
3. GPU管控：用“使用配额”限制GPU任务，避免滥用。
4. 资源治理：培训开发者的资源节约意识，同时自动删除空闲资源。
5. 流程推动：在组织内推行TAG Green Reviews（绿色审查）。


## 九、参考资源
1. KEPLER Project（开源能源监控项目）
2. Green Reviews Tooling（绿色审查工具）
3. Cloud Native Sustainability Landscape（云原生可持续发展图谱）
4. 视频资源：《Go Green with K8s》
5. 文档资源：《Green AI in Cloud Native Ecosystems》
6. 工作组资源：TAG Env WG Green Reviews（原环境工作组绿色审查）