# 《letsgo: The Ultimate Platform CLI》PDF总结  
本文档基于SeatGeek公司在2025年11月10日“Platform Engineering Day”的演讲内容，核心介绍了内部平台CLI工具**letsgo**的设计背景、功能特性、使用场景及落地效果。


## 一、文档基本信息  
| 项目                | 详情                                                                 |
|---------------------|----------------------------------------------------------------------|
| 演讲标题            | letsgo: The Ultimate Platform CLI                                    |
| 演讲者              | Colin O’Dell（@colinodell），SeatGeek公司Lead Software Engineer      |
| 所属团队            | Platform // Developer Experience（平台//开发者体验团队）              |
| 演讲时间            | 2025年11月10日                                                       |
| 重要备注            | 1. letsgo目前**尚未开源**；2. 部分示例经过简化或信息编辑（redacted） |


## 二、核心背景：为什么需要平台CLI？  
内部开发平台（IDP）虽能解决大部分问题，但无法覆盖工程师的全场景需求。letsgo的设计初衷是满足两类核心诉求：  

### 1. 高效使用工作站（本地环境）  
- 确保本地机器配置合规（自动校验+修复）；  
- 快速搭建、切换本地项目；  
- 自动续签本地认证令牌（避免重复手动操作）。  

### 2. 便捷对接平台能力（云端/集群）  
- 应用预扩容：如在${MAJOR_ARTIST}（头部艺人）票务开售前，提前扩容应用；  
- 部署管控：冻结部署、回滚应用版本；  
- 资源访问：获取 staging（预发布环境）数据库的只读凭证等。  


## 三、letsgo CLI 定位与核心优势  
letsgo是SeatGeek为内部平台打造的全场景CLI工具，核心优势可概括为4点：  

| 优势                | 详细说明                                                                 |
|---------------------|--------------------------------------------------------------------------|
| **“开箱即用”跨场景** | 支持终端、CI流水线、Bash脚本；预安装在工程师设备上；运行时自动修复环境问题（预飞行检查）。 |
| **强标准化**        | 内置最佳实践与“黄金路径”；底层调用原生工具（aws、argocd、kubectl）和API，复用用户本地凭证。 |
| **高可组合**        | 提供75+个子命令，每个命令仅专注单一功能；原生支持JSON输出（便于脚本化调用）。             |
| **内建协作（Inner-Sourced）** | 平台团队维护核心功能；任何业务团队均可贡献子命令（降低扩展门槛）。                        |


## 四、核心命令示例  
letsgo的命令按“功能域”分类，覆盖应用管理、数据存储、身份认证等场景，下表整理高频命令：  

| 功能域          | 命令格式                                                                 | 用途说明                                                                 |
|-----------------|--------------------------------------------------------------------------|--------------------------------------------------------------------------|
| **应用管理**    | `letsgo app config [get|set|show|unset]`                                 | 查看/设置/展示/删除应用配置                                               |
|                 | `letsgo app restart` / `letsgo app rollback`                             | 重启应用 / 回滚应用版本                                                  |
|                 | `letsgo app scale [set|show|unset]`                                      | 扩容/查看/取消应用实例数（如预扩容）                                      |
|                 | `letsgo app rollouts [promote|retry]`                                    | 推进部署流程 / 重试失败的部署                                            |
| **数据存储**    | `letsgo datastore [mysql|postgres|redis] [connect|credentials|list]`     | 连接数据库/获取临时凭证/列出数据存储实例（支持MySQL、PostgreSQL、Redis） |
| **部署管控**    | `letsgo freeze [start|end]`                                              | 启动/结束部署冻结（避免关键时段变更）                                    |
| **身份与密钥**  | `letsgo login` / `letsgo vault [login|read|whoami]`                     | 统一登录平台 / Vault密钥管理（登录、读取密钥、查看当前身份）              |
| **开发者门户**  | `letsgo backstage [go|preview|validate]`                                 | 跳转Backstage页面 / 预览配置 / 校验配置合规性                            |
| **版本管理**    | `letsgo version [check|upgrade]`                                          | 检查版本更新 / 升级letsgo                                                |
| **自定义项目**  | `letsgo <group/repo-name>`                                               | 快速对接特定代码仓库的自定义命令（如团队专属工具）                        |


### 典型场景示例：获取临时数据库凭证  
以“获取Backstage服务的staging环境PostgreSQL只读凭证”为例，核心逻辑如下：  
1. **预检查**：自动校验VPN是否连接、Vault是否已认证（未通过则触发修复，如引导Vault登录Okta）；  
2. **凭证获取**：调用Vault客户端读取服务（backstage）、角色（read-only）对应的临时凭证；  
3. **输出结果**：生成可直接使用的DSN（数据库连接字符串），并显示用户名、密码、过期时间（如`2025-11-10T15:30:00Z`）。  

关键代码逻辑片段（简化）：  
```go
type Model struct {
    VaultClient vault.Client `letsgo:",dependency"` // 依赖Vault客户端
    Database    string       `json:"database"`
    Username    string       `json:"username"`
    Password    string       `json:"password"`
    DSN         string       `json:"dsn"`
    LeaseExpiry string       `json:"lease_expiry"`
}

// 命令执行逻辑
Action: func(cmd *Command) error {
    // 从Vault获取凭证
    cmd.Data, err = cmd.Config.VaultClient.ReadDbCredentials(cmd.Config.ServiceName, cmd.Config.Role)
    // 生成DSN
    cmd.Data.DSN = fmt.Sprintf("postgres://%s:%s@%s:%d/%s", 
        cmd.Data.Username, cmd.Data.Password, cmd.Data.Hostname, cmd.Data.Port, cmd.Data.Database)
    return nil
}
```


## 五、letsgo 关键特性（核心竞争力）  
### 1. 预飞行检查（Pre-flight Checks）—— 环境问题“自动修复”  
- **检查范围**：共55项检查，覆盖「系统认证」「配置合规」「网络连通性」「必备二进制工具（如git、aws-cli）」等；  
- **修复能力**：43项检查支持自动修复（FIXABLE），例如：  
  - 检测到Vault未登录时，自动引导通过Okta登录；  
  - 检测到aws-cli配置无效时，提示并修复SSO会话；  
- **技术设计**：定义统一接口实现扩展性，示例：  
  ```go
  type Checker interface { ID() ID; Check(context.Context) *Result } // 检查接口
  type Fixer interface { Fix(context.Context) *Result }             // 修复接口
  type Depender interface { Dependencies(context.Context) []ID }    // 依赖管理接口
  ```

### 2. 自动与手动更新  
- **自动更新**：通过macOS plist配置（每3小时执行一次），自动触发版本升级：  
  ```xml
  <key>Label</key><string>com.seatgeek.letsgo.auto-upgrade</string>
  <key>Program</key><string>/Users/codell/.letsgo/bin/letsgo</string>
  <key>ProgramArguments</key><array><string>letsgo</string><string>version</string><string>upgrade</string></array>
  <key>StartInterval</key><integer>10800</integer> <!-- 3小时=10800秒 -->
  ```
- **手动更新**：支持指定版本/分支升级，示例：  
  ```bash
  letsgo version upgrade          # 升级到最新版
  letsgo version upgrade --stable # 升级到稳定版
  letsgo version upgrade pr/1234  # 升级到PR#1234的版本
  ```

### 3. 其他核心特性  
| 特性                | 说明                                                                 |
|---------------------|----------------------------------------------------------------------|
| **简易安装**        | 工程师设备预安装；其他环境可通过一键脚本安装：`bash <(curl -s install.sh)` |
| **文档与可发现性**  | 1. 文档自动生成（Markdown格式）；2. 支持`--help`、Backstage Techdocs查阅；3. 子命令/参数支持Tab补全。 |
| **多输出格式**      | 默认文本输出（人类可读）；`--json` flag输出JSON（脚本化场景）；复杂场景提供交互式TUI。 |
| **遥测（Telemetry）** | 记录每条命令的「子命令、脱敏后的参数/ flags、退出码、预检查结果、用户名、OS、版本」，用于监控bug、用户痛点、版本漂移，辅助命令 deprecate（废弃）决策。 |


## 六、落地效果与贡献情况  
### 1. 高 adoption（采用率）  
- 100% SeatGeek工程师**定期使用**letsgo；  
- 每周执行**30,000条命令**，其中17,000条来自人工操作（非自动化脚本），覆盖日常开发全流程。  

### 2. 团队协作贡献  
- 累计收到**2,156个Pull Request（PR）** ；  
- 贡献者覆盖**60个不同团队**（不仅限于平台团队，体现内建协作价值）。  


## 七、补充信息  
- 演讲幻灯片获取：可通过SeatGeek官方渠道获取；  
- 更多细节：参考SeatGeek Platform & Engineering Blog（平台与工程博客）。