# OpenTelemetry for Platform Engineers: Paving the Road to Self-Service Observability
## 一、文档基本信息
- **主题**：面向平台工程师的OpenTelemetry——构建自助式可观测性之路
- **主讲人**：Kasper Borg Nissen  
  职位与身份：Dash0首席开发者布道师、前KubeCon+CloudNativeCon EU/NA 24/25联合主席、CNCF大使、Golden Kubestronaut、CNCG Aarhus与KCD丹麦组织者、Cloud Native Nordics联合创始人及社区负责人  
- **相关资源**：Demo地址（https://github.com/dash0hq/otel-platform-demo）、参考链接（https://university.platformengineering.org/observability-for-platform-engineering）


## 二、当前可观测性的核心痛点
微服务架构下的**遥测数据碎片化**，导致一系列问题：
1. 复杂的查询语言（Complex Query Languages）
2. 供应商锁定（Vendor Lock-in）
3. 元数据不一致（Metadata Inconsistency）
4. 因复杂度高无法实现 instrumentation（No instrumentation due to high complexity）
5. 缺乏统一洞察（Lack of unified insights）


## 三、平台工程师在可观测性中的双重角色
平台工程师需兼顾“平台观测”与“开发者赋能”两大职责：
1. **观测平台本身**：监控云、集群、CI/CD流水线、共享数据库等基础设施
2. **赋能开发者**：提供自动 instrumentation、日志/指标/追踪数据的采集能力


## 四、CNCF可观测性及相关工具生态
文档列出CNCF旗下多领域工具，覆盖可观测性、混沌工程、持续优化、特性标记等，核心分类如下：
| 领域                | 代表性工具（含CNCF成熟度）                                                                 |
|---------------------|------------------------------------------------------------------------------------------|
| 可观测性（毕业级）  | fluentd、cortex、OpenTelemetry                                                           |
| 可观测性（孵化级）  | Thanos、beats、Chaos Mesh、Litmus、botkube、Grafana Mimir、Pixie等                        |
| 混沌工程            | Gremlin、ChaosMeta、krkn                                                                 |
| 持续优化            | OpenCost、nOps、ScaleOps、Densify                                                        |
| 特性标记            | Flipt、split（CNCF孵化级）                                                               |


## 五、OpenTelemetry核心解析
### 1. 定义：是什么 & 不是什么
| 维度       | 具体说明                                                                 |
|------------|--------------------------------------------------------------------------|
| **What it is** | - CNCF第二大贡献者项目（按贡献者数量）<br>- 聚焦遥测数据采集的标准化套件，含：数据模型、API规范、语义约定、多语言库、工具等 |
| **What it is NOT** | - 非专有工具<br>- 非“一体化可观测性工具”<br>- 非数据存储/仪表盘解决方案<br>- 非查询语言<br>- 非性能优化器<br>- 非功能完备工具 |

### 2. 关键数据与支持信号
- **2024-2025年项目数据**（来源：CNCF Velocity）：提交量（Commits）44,486次、PR+Issues 56,299个（注：文档中同时提及另一组数据27,168次提交、58,508个PR+Issues，均为该周期内统计）
- **支持的遥测信号**：日志（Logs）、指标（Metrics）、追踪（Traces）、性能分析（Profiles）、真实用户监控（RUM）


## 六、可观测性的核心理念与平台工程原则
### 1. 可观测性核心理念
- 本质是“系统问题”，而非孤立的“指标/日志/追踪问题”
- **关联（Correlation）是核心能力**：需打通日志、指标、追踪等信号，实现数据联动
- 可观测性即产品（Observability as a Product）：需“无形但始终存在”（invisible but never absent）
- 数字平台定义（引用Evan Bottcher）：由自助API、工具、服务、知识和支持构成的“有吸引力的内部产品”

### 2. 平台工程核心原则
- 自助体验（Self-Service Experience）
- 明确且一致的API（Explicit and Consistent APIs）
- 黄金路径（Golden Paths）
- 模块化（Modularity）
- 平台即产品（Platform as a Product）


## 七、OpenTelemetry技术实现：标准化遥测架构
### 1. 核心组件：OpenTelemetry Collector
- 定位：“最后一个需要安装的可观测性代理”（The last observability agent you will ever install）
- 核心功能：标准化遥测数据采集，流程为**接收（Receive）→处理（Process）→导出（Export）**
- 作用：连接“遥测数据生成端”（如K8s、应用）与“后端存储/分析端”（如Prometheus、Jaeger、OpenSearch）

### 2. Collector部署方式与配置示例
| 部署方式       | 接收器（Receivers）                          | 处理器（Processors）                | 导出器（Exporters）                  |
|----------------|---------------------------------------------|-------------------------------------|-------------------------------------|
| DaemonSet      | kubeletstat、filelog、hostmetrics、otlp      | k8sattributes、attributes/flatten、batch | Jaeger、Prometheus、OpenSearch、dashO |
| Deployment     | k8s_cluster、k8sobjects、rabbitmq、prometheus、otlp | k8sattributes、attributes/flatten、attributes/redact、batch | Jaeger、Prometheus、OpenSearch、dashO |

### 3. 无接触Instrumentation（No-Touch Instrumentation）
- 实现工具：OpenTelemetry Operator
- 核心能力：在Kubernetes Pod中自动注入instrumentation，支持多语言，无需开发者手动配置
- 多语言注解示例：
  - Go：`instrumentation.opentelemetry.io/inject-go: "<ns>/<instrumentation>"`
  - Java：`instrumentation.opentelemetry.io/inject-java: "<ns>/<instrumentation>"`
  - .NET、Node.js、Python：类似注解（替换语言标识即可）


## 八、Demo：OpenTelemetry实战架构
### 1. 环境与架构演进
- 基础环境：Kubernetes Kind集群
- 架构演进：
  1. 初始架构：前端（React）+ todo-service + MySQL
  2. 扩展架构：增加notification-service + RabbitMQ
  3. 最终架构：新增validation-service（用于校验todo内容、检测不良词汇）

### 2. 核心配置与组件联动
- **Instrumentation CRD配置**：指定采样器（always_on）、导出端点（http://otel-collector.sve.cluster.local:4317）、开启K8s UID属性注入
- **validation-service部署注解**：`instrumentation.opentelemetry.io/inject-nodejs: "opentelemetry/instrumentation"`
- **组件联动**：OpenTelemetry Collector连接Prometheus（指标）、Jaeger（追踪）、OpenSearch（日志）、dashO（分析）、Perses（仪表盘）


## 九、核心结论
1. 可观测性领域发展迅速，标准化是关键趋势
2. OpenTelemetry标准化“遥测数据采集”，Perses标准化“仪表盘”
3. 应用平台工程原则可将可观测性从“事后补救”转为“无缝、可扩展、开发者友好”的体验
4. 可观测性的核心价值：连接遥测信号，帮助开发者更快解决系统问题