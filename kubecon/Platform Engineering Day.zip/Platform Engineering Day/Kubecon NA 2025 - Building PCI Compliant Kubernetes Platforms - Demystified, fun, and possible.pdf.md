# KubeCon NA 2025：构建PCI合规的Kubernetes平台——解密、趣味与可行性
## 1. 作者与背景
- **主讲人**：Julien Semaan（Akamai Cloud 高级架构师、CNCF TAG DevEx 技术负责人）、Tarun Chinmai Sekar（Akamai Cloud 首席软件工程师）
- **核心目标**：证明PCI合规Kubernetes平台的可行性，核心是“拥抱自动化+做出合理权衡”，并降低合规复杂度。


## 2. 核心挑战：PCI在Kubernetes上的难点
本质是**传统合规与云原生理念的“文化冲突”**，叠加自管理K8s的额外责任，具体对比与挑战如下：

### 2.1 传统合规 vs 云原生理念对比
| 维度                | 传统PCI DSS合规                  | Kubernetes云原生理念              |
|---------------------|----------------------------------|-----------------------------------|
| 操作模式            | 清单式检查（Checklist）          | 声明式配置（YAML、Git）           |
| 证据收集            | 手动（表格、工单）               | 自动化（Git版本控制、审计日志）   |
| 审计频率            | 周期性（季度、年度）             | 持续变更（每日/每小时部署）       |
| 基础设施特性        | 静态（VM、物理设备）             | 短暂性（Pod伸缩、动态调度）       |
| 审批流程            | 自上而下的审批门控               | 自动化流水线（CI/CD、GitOps）     |

### 2.2 额外挑战
自管理Kubernetes需“继承”原本由托管服务覆盖的合规责任，增加平台团队负担。


## 3. 构建合规平台的指导原则
共10项核心原则，贯穿平台设计全流程：
1. **GitOps优先**：所有配置声明式管理、版本可控、可审计；
2. **严格审批机制**：明确权限升级流程，避免无序操作；
3. **不可变基础设施**：减少手动修改，降低漂移风险；
4. **全链路可审计**：所有操作留痕，支持审计追溯；
5. **强制政策执行**：通过工具自动化落地安全标准；
6. **零信任架构**：默认不信任任何内部/外部访问，需显式授权；
7. **最小权限访问**：仅授予完成工作必需的权限；
8. **平台原生SSO/RBAC**：提供“零配置”SSO集成与预置RBAC角色；
9. **左移合规**：将安全合规嵌入SDLC（开发阶段），而非仅运维阶段；
10. **简化用户路径**：平台封装合规复杂性，为用户提供“黄金路径”。


## 4. 高层架构设计
采用“**管理集群+应用集群**”分层架构，实现集中管控与租户隔离，具体职责如下：

| 集群类型          | 核心功能                                  | 维护/所有者                | 关键能力输出                  |
|-------------------|-------------------------------------------|---------------------------|-------------------------------|
| 全球管理集群      | 集中用户入职、应用注册、统一监控（Single Pane of Glass） | Platform SRE团队          | 标准化集群模板、全局政策管控  |
| 应用集群          | 独立平台实例，运行具体业务应用            | 业务团队（App Teams）     | 内置部署流程、版本化平台单元  |

### 4.1 架构关键组件
- 基础设施：RKE2（Kubernetes发行版）；
- 编排工具：Argo（GitOps部署）、Crossplane（基础设施状态协调）；
- 集成能力：Github Platform API（代码托管与流水线）、Platform CLI（用户操作入口）；
- 平台保障：自动密钥轮换、自动化备份/恢复。


## 5. GitOps与PCI的融合优势（GitOps + PCI = ❤️）
GitOps是解决PCI合规与K8s动态性矛盾的核心方案，核心价值如下：
1. **全声明式管理**：集群拓扑、配置、OS版本（基于Ubuntu快照服务）均存储于Git，版本可控；
2. **内置审计与证据**：
   - 分支保护、代码签名提供操作追溯；
   - ArgoCD作为“单一窗口”：统一变更审批、自动记录证据，简化审计收集；
3. **防漂移与安全锁**：
   - Crossplane持续协调“期望状态”，自动回滚手动修改；
   - 基础设施“锁定”，避免未授权变更；
4. **标准化部署**：团队基于平台预置的PCI合规最佳实践部署应用，降低人为失误。


## 6. 平台安全控制及示例
通过工具链自动化落地安全控制，覆盖审批、漏洞、网络、日志、政策5大维度，附具体配置示例：

### 6.1 核心安全控制措施
| 控制维度          | 实现方案                                  | 关键作用                          |
|-------------------|-------------------------------------------|-----------------------------------|
| 双重审批          | Github Action流水线需≥2名核心 stakeholder 审批 | 避免单人操作风险，审批日志不可变  |
| 持续漏洞监控      | Trivy（扫OCI镜像）+ Osquery→fleetdm（OS包监控） | 实时发现镜像/系统层漏洞           |
| 网络安全          | Cilium+Hubble+Istio                      | 默认防火墙，通过Akamai零信任客户端限制访问；Hubble可视化流量流向 |
| 审计日志          | 默认记录所有操作，告警异常非SSO访问（kubectl/SSH） | 及时发现未授权访问               |
| 政策强制          | Kyverno + Pod Security Policies（PSP）    | 自动化执行Pod安全标准，如“非root运行” |

### 6.2 关键配置示例
#### 示例1：Kyverno Pod安全策略（强制Restricted级别）
```yaml
# 1. 准入控制配置：默认Enforce/Audit/Warn均为Restricted级别
apiVersion: apiserver.config.k8s.io/v1
kind: AdmissionConfiguration
plugins:
- name: PodSecurity
  configuration:
    apiVersion: pod-security.admission.config.k8s.io/v1beta1
    kind: PodSecurityConfiguration
    defaults:
      enforce: "restricted"
      enforce-version: "latest"
      audit: "restricted"
      audit-version: "latest"
      warn: "restricted"
      warn-version: "latest"
    exemptions: # 豁免命名空间（如kube-system、ingress）
      namespaces: [kube-system, ingress]

# 2. Kyverno集群政策：绑定Restricted规则
apiVersion: kyverno.io/v1
kind: ClusterPolicy
metadata:
  name: pss-restricted-policy
spec:
  rules:
  - name: restricted
    match:
      any:
      - resources:
          kinds: [Pod]
    validate:
      podSecurity:
        level: restricted
        version: latest

# 3. 政策例外：Istio Proxy镜像允许非root运行
apiVersion: kyverno.io/v2
kind: PolicyException
metadata:
  name: istio-exception
  namespace: kyverno-system
spec:
  exceptions:
  - policyName: pss-restricted-policy
    ruleNames: [restricted]
  match:
    all:
    - resources:
        kinds: [Pod]
        namespaces: [ingress]
    podSecurity:
    - controlName: "Running as Non-root"
      images: ["docker.io/istio/proxy*"]
```

#### 示例2：关键安全告警规则
1. **SSH未知来源登录告警**（仅允许特定IP，Critical级别）：
   ```yaml
   - name: SSHLoginFromUnknownSource
     rules:
     - alert: SSHLoginFromUnknownSource
       expr: |
         sum(count_over_time({ service_name="auth-log" } | username =~ `.+` | 
         sourceIP != `88.98.28.69` | sourceIP != `88.98.28.70` | 
         sourceIP != `99.98.28.69` | sourceIP != `99.98.28.70` [5m])) > 0
       for: 0m
       labels: { severity: critical }
   ```
2. **Kubectl紧急凭证使用告警**（cluster-admin账号仅允许特定IP，Critical级别）：
   ```yaml
   - name: KubectlEmergencyCredsUsed
     rules:
     - alert: KubectlEmergencyCredsUsed
       expr: |
         sum(count_over_time({ service_name="audit-log" } | 
         userId = `system:serviceaccount:kube-system:cluster-admin` | 
         sourceIP != `88.98.28.69` | sourceIP != `88.98.28.70` | 
         sourceIP != `99.98.28.69` | sourceIP != `99.98.28.70` [5m])) > 0
       for: 0m
       labels: { severity: critical }
   ```


## 7. RBAC与SSO实现
核心是“**内置OIDC+GitOps驱动角色分配**”，无需第三方组件，简化配置与审计：
1. **SSO基础**：
   - 基于Kubernetes API服务器内置OIDC，支持Kubelogin+PKCE，实现所有用户统一配置；
   - 平台预置SSO，用户“零配置”接入。

2. **RBAC管理**：
   - GitOps驱动：角色分配配置存储于Git，通过CODEOWNERS审核确保合规；
   - 简化配置格式：明确IAM组/用户与平台角色的映射，示例如下：
     ```yaml
     # Git仓库中存储的简化配置（渲染为完整集群定义）
     name: demo-cluster
     cluster:
       auth:
         oidc:
           enabled: true
           roleMapping:
             - group: "myProductDevs" # OIDC组名
               roles: ["read"] # 平台内置角色（只读）
             - group: "myProductSREs"
               roles: ["read-write"] # 平台内置角色（读写）
             - group: "l2Support"
               roles: ["demo-cluster-reader"] # 自定义角色
             - user: <OIDC username> # 临时单用户授权
     ```
   - 角色权限示例（ClusterRole）：
     ```yaml
     apiVersion: rbac.authorization.k8s.io/v1
     kind: ClusterRole
     metadata:
       name: demo-cluster-reader
     rules:
     - apiGroups: [""]
       resources: ["nodes", "pods"]
       verbs: ["watch", "list", "get"] # 仅只读权限
     ```


## 8. 共享责任模型
明确平台团队与用户团队的合规边界，避免责任模糊：

| 责任方              | 具体职责                                  |
|---------------------|-------------------------------------------|
| 平台团队（Platform）| 1. 提供PCI合规的控制平面；<br>2. 提供合规工具、文档与集成能力；<br>3. 确保租户隔离（尤其是PCI/非PCI环境）；<br>4. 封装底层合规复杂度 |
| 平台用户（Teams）   | 1. 利用平台能力构建PCI合规系统；<br>2. 确保自身SDLC符合PCI要求；<br>3. 处理持卡人数据（平台不收集/存储/传输该数据） |

### 8.1 最终价值
- 团队获得“文档化+用户友好”的合规黄金路径；
- 审计响应可跨系统复用，减少重复工作。


## 9. 结尾
- 引用DJ Khaled作为“（意外的）合规思想领袖”，传递“合规可实现且可趣味化”的理念；
- 开放问答环节，进一步解答实践细节。