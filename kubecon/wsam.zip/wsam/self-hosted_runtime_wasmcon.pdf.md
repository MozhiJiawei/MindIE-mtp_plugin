# 《What If the Runtime Was Portable Too? Self-Hosted Runtime Capabilities in Wasm》PDF总结
## 一、文档基础信息
- **会议/主题**：WASMCON NORTH AMERICA（北美WebAssembly大会），核心议题为“Wasm运行时的可移植性与自托管运行时能力”
- **作者**：Yuki Nakata（X账号：@chiku_wait），日本SAKURA internet公司研究员/北海道未来大学博士生
- **核心项目**：自托管运行时原型（PoC）——Chiwawa，GitHub地址：https://github.com/oss-fun/chiwawa


## 二、Wasm的核心特性：可移植性基础
Wasm的“一次编写，到处运行（Write once, run anywhere）”依赖两大核心属性：
1. **语言无关性**：不同编程语言可编译为Wasm字节码，无需针对特定语言适配运行时。
2. **硬件与平台无关性**：Wasm字节码通过运行时（Wasm Runtime）抽象硬件差异，可在Intel、sel4等不同硬件/平台上执行，无需修改代码。


## 三、Wasm运行时的多样性与挑战
### 1. 运行时多样性现状
- **数量与差异**：目前存在**100+种Wasm运行时**（引用2025年ACM Trans. Softw. Eng. Methodol.论文：《Research on WebAssembly Runtimes: A Survey》，DOI：10.1145/3714465），核心差异体现在：
  - 执行模型：解释器（Interpreter）、即时编译（JIT）、提前编译（AOT）；
  - 目标场景：高性能计算（如Wasmtime，JIT优化）、AI/LLM（如WasmEdge，丰富扩展）。

### 2. 可移植性限制
不同运行时对Wasm特性的支持不一致，导致代码无法跨运行时兼容，典型示例如下（部分特性支持状态）：

| 特性                  | Chrome | Firefox | Safari | Node.js | Deno  | Wasmtime | Wasmer  |
|-----------------------|--------|---------|--------|---------|-------|----------|---------|
| JS BigInt to Wasm i64 | 85%    | 78%     | 15.4   | 15.0    | 1.1.2 | N/A      | N/A     |
| 分支提示（Branch Hinting） | 137+ | 131+ | 18.4 | - | 2.3.2 | 不支持 | 不支持 |
| 批量内存操作（Bulk Memory） | 75+ | 79+ | 15.4 | 12.5 | 0.4 | 0.20 | 1.0 |
| 垃圾回收（Garbage Collection） | 119+ | 120+ | 18.2 | 22.0 | 1.38 | 部分支持 | 不支持 |

此外，运行时还存在“专属功能差异”，例如WasmEdge支持特定统计与资源限制：
- 统计信息：`--enable-time-measuring`（执行时间）、`--enable-gas-measuring`（gas消耗）等；
- 资源限制：`--time-limit`（时间上限）、`--gas-limit`（gas上限）、`--memory-page-limit`（内存页限制，单页64KiB）。


## 四、解决方案：自托管运行时（Self-hosted Runtime）
### 1. 定义与核心逻辑
- **本质**：最小化的“Wasm化Wasm运行时”（Minimal Wasm-ised Wasm Runtime），作为**宿主运行时（Host Runtime）的兼容层**；
- **优势**：仅需向自托管运行时实现扩展，无需修改宿主运行时（如Wasmtime、WasmEdge），实现“一次扩展，跨运行时可用”。

### 2. 架构逻辑
```
Wasm字节码 → 自托管运行时（兼容层） → 宿主运行时（如Wasmtime/WasmEdge）
```


## 五、自托管运行时的典型用例
### 1. 跨运行时检查点/恢复（C/R）
- **痛点**：传统C/R需修改运行时优化（如JIT/AOT），适配不同运行时实现；
- **方案**：在自托管运行时中统一保存/恢复应用状态，无需考虑宿主运行时差异；
- **进展**：已在Chiwawa中实现，支持Wasmtime、WasmEdge等宿主运行时。

### 2. 追踪与插桩（Tracing & Instrumentation）
- **场景**：调试（bug检测）、执行流可视化、性能分析（Profiling）；
- **优势**：可追踪自托管运行时的VM状态，且不受宿主运行时优化影响，无需修改任何宿主运行时。

### 3. 执行运行时不支持的功能
- **场景**：宿主运行时仅支持旧版标准（如WASI p1），需运行新版功能（如WASI p2）；
- **方案**：将自托管运行时编译为宿主支持的Wasm字节码，通过自托管运行时实现新版接口，间接在宿主上执行；
- **进展**：Chiwawa中已纳入考虑（WASI p2兼容WASI p1场景）。


## 六、性能分析与优化
### 1. 性能开销来源
1. **指令膨胀**：应用的1条指令需转换为自托管运行时的多条指令（如`local.get`需拆分为“读取上下文→压栈”等步骤）；
2. **计算重复**：沙箱机制（Sandbox）、WASI实现等计算密集型逻辑在宿主与自托管运行时中重复执行。

### 2. 优化技术
1. **指令合并（Merging Instructions）**：解析指令依赖，将栈指令转换为“立即值指令”，减少指令数量。  
   示例：`i32.const 10 → local.get 0 → i32.add → local.set 1` 合并为 `i32.add{10, local@0} => local@1`；
2. **直通WASI实现（Pass-through WASI）**：跳过WASI接口转换，直接将调用重定向到宿主运行时的WASI实现，减少重复计算。

### 3. 优化效果
- **优化后 overhead**：Chiwawa on Wasmtime 相对原生Wasmtime，性能开销控制在**1.3~1.4倍**；
- **未优化对比**：部分场景（如I/O密集型）性能下降达**13~426倍**；
- **自托管运行时间对比**（执行时间，单位：秒）：

| 基准测试（Benchmark） | Wizard on Wizard（自托管） | Chiwawa on Wizard（自托管） |
|-----------------------|----------------------------|-----------------------------|
| pi-Leibniz（圆周率计算） | 26.791                     | 19.620                      |
| N-body（天体模拟）      | 14.554                     | 9.932                       |


## 七、结论与未来目标
### 1. 核心价值
自托管运行时解决了Wasm跨运行时兼容问题，可快速实现/测试新功能，且无需修改现有宿主运行时。

### 2. 关键挑战与目标
- **当前问题**：存在显著性能开销；
- **未来目标**：将自托管运行时的性能优化至“与现有解释器运行时（Interpreter Runtime）相当”。